// middleware.ts — Route protection middleware

import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from '@/lib/auth';

// Routes that require authentication
const PROTECTED_ROUTES = ['/dashboard', '/pos', '/inventory', '/reports', '/settings'];
// Routes that should redirect to app if already logged in
const AUTH_ROUTES = ['/'];
// API routes that require authentication
const PROTECTED_API = ['/api/products', '/api/sales', '/api/dashboard', '/api/users',
                        '/api/inventory', '/api/categories', '/api/ai-search', '/api/reports'];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const token = req.cookies.get('smartpos_session')?.value;

  // ─── Protect API routes ───────────────────────────────
  if (PROTECTED_API.some(route => pathname.startsWith(route))) {
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const user = await verifyToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Session expired' }, { status: 401 });
    }
    return NextResponse.next();
  }

  // ─── Protect page routes ──────────────────────────────
  if (PROTECTED_ROUTES.some(route => pathname.startsWith(route))) {
    if (!token) {
      return NextResponse.redirect(new URL('/', req.url));
    }
    const user = await verifyToken(token);
    if (!user) {
      const res = NextResponse.redirect(new URL('/', req.url));
      res.cookies.delete('smartpos_session');
      return res;
    }
    return NextResponse.next();
  }

  // ─── Redirect logged-in users away from login ──────────
  if (AUTH_ROUTES.includes(pathname) && token) {
    const user = await verifyToken(token);
    if (user) {
      return NextResponse.redirect(new URL('/pos', req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|icon-192.png|manifest.json|sw.js).*)',
  ],
};
