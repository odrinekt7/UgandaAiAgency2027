'use client';
// app/pos/page.tsx — Main Point of Sale Screen

import { useState, useCallback, useEffect, useRef } from 'react';
import toast from 'react-hot-toast';
import { clsx } from 'clsx';
import {
  MdSearch, MdAdd, MdRemove, MdDelete,
  MdPayment, MdReceipt, MdQrCodeScanner,
  MdLocalOffer, MdCheck
} from 'react-icons/md';
import { useCartStore } from '@/store/cartStore';
import { useBarcode } from '@/hooks/useBarcode';
import { queueOfflineSale, isOnline, getProductByBarcode } from '@/lib/offline';
import type { Product, PaymentMethod } from '@/types';
import { format } from 'date-fns';

const PAYMENT_METHODS: { id: PaymentMethod; label: string; icon: string }[] = [
  { id: 'CASH', label: 'Cash', icon: '💵' },
  { id: 'MTN_MOBILE_MONEY', label: 'MTN MoMo', icon: '📱' },
  { id: 'AIRTEL_MONEY', label: 'Airtel Money', icon: '📲' },
  { id: 'CARD', label: 'Card', icon: '💳' },
];

export default function POSPage() {
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searching, setSearching] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showReceipt, setShowReceipt] = useState<any>(null);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);

  const cart = useCartStore();
  const TAX_RATE = 0; // Load from business settings

  // ─── Barcode scanning ──────────────────────────────────
  useBarcode({
    onScan: async (barcode) => {
      toast.loading('Looking up barcode...', { id: 'barcode' });

      // Try offline cache first
      let product = await getProductByBarcode(barcode);

      if (!product && isOnline()) {
        const res = await fetch(`/api/products?barcode=${barcode}`);
        const data = await res.json();
        product = data.data?.[0];
      }

      if (product) {
        cart.addItem(product);
        toast.success(`Added: ${product.name}`, { id: 'barcode' });
      } else {
        toast.error(`Barcode not found: ${barcode}`, { id: 'barcode' });
      }
    },
    enabled: !showCheckout,
  });

  // ─── Product search ────────────────────────────────────
  const handleSearch = useCallback(async (query: string) => {
    setSearch(query);
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    setAiSuggestion('');

    try {
      const res = await fetch('/api/ai-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const data = await res.json();
      setSearchResults(data.data || []);
      if (data.suggestion) setAiSuggestion(data.suggestion);
    } catch {
      // Fallback: offline search
      const { searchCachedProducts } = await import('@/lib/offline');
      const results = await searchCachedProducts(query);
      setSearchResults(results);
    } finally {
      setSearching(false);
    }
  }, []);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (search) handleSearch(search);
    }, 300);
    return () => clearTimeout(timer);
  }, [search, handleSearch]);

  // ─── Checkout ──────────────────────────────────────────
  const handleCheckout = async () => {
    if (cart.items.length === 0) return;

    const total = cart.getTotal(TAX_RATE);
    const amountPaid = cart.amountPaid;

    if (cart.paymentMethod === 'CASH' && amountPaid < total) {
      toast.error('Amount paid is less than total');
      return;
    }

    setProcessingPayment(true);

    const payload = {
      items: cart.items.map((i) => ({
        productId: i.product.id,
        quantity: i.quantity,
        unitPrice: i.product.sellingPrice,
        discount: i.discount,
      })),
      paymentMethod: cart.paymentMethod as PaymentMethod,
      amountPaid: cart.paymentMethod === 'CASH' ? amountPaid : total,
      discountAmount: cart.getSubtotal() * (cart.globalDiscount / 100),
    };

    try {
      if (!isOnline()) {
        // Queue for sync later
        const offlineId = await queueOfflineSale(payload);
        toast.success('Sale saved offline — will sync when internet returns');
        setShowReceipt({ offline: true, total, items: cart.items, id: offlineId });
        cart.clearCart();
        setShowCheckout(false);
        return;
      }

      const res = await fetch('/api/sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'Payment failed');
        return;
      }

      toast.success(`Sale complete! Receipt: ${data.data.receiptNumber}`);
      setShowReceipt(data.data);
      cart.clearCart();
      setShowCheckout(false);
    } catch {
      // Network failed — go offline
      await queueOfflineSale(payload);
      toast.success('No internet — sale saved offline');
      cart.clearCart();
      setShowCheckout(false);
    } finally {
      setProcessingPayment(false);
    }
  };

  const subtotal = cart.getSubtotal();
  const total = cart.getTotal(TAX_RATE);
  const change = cart.getChange(TAX_RATE);
  const itemCount = cart.getItemCount();

  return (
    <div className="flex h-screen overflow-hidden">
      {/* ── LEFT: Product Search ────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Search Header */}
        <div className="p-4 bg-surface-1 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="flex-1 relative">
              <MdSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" size={20} />
              <input
                ref={searchRef}
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search products or scan barcode..."
                className="input-base pl-11 text-base"
                autoFocus
              />
              {searching && (
                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-brand/30 border-t-brand rounded-full animate-spin" />
              )}
            </div>
            <div className="flex items-center gap-1 px-3 py-2 bg-surface-2 border border-white/10 rounded-xl text-xs text-white/40">
              <MdQrCodeScanner size={16} className="text-brand" />
              <span>Scan ready</span>
            </div>
          </div>
          {aiSuggestion && (
            <p className="mt-2 text-xs text-brand/70 flex items-center gap-1.5">
              <span className="text-brand">✨</span>
              {aiSuggestion}
            </p>
          )}
        </div>

        {/* Search Results */}
        <div className="flex-1 overflow-y-auto p-4">
          {searchResults.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
              {searchResults.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAdd={() => cart.addItem(product)}
                />
              ))}
            </div>
          ) : search ? (
            <div className="text-center py-20 text-white/30">
              <MdSearch size={40} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">No products found for "{search}"</p>
            </div>
          ) : (
            <div className="text-center py-20 text-white/20">
              <MdQrCodeScanner size={48} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium text-white/40">Ready to scan or search</p>
              <p className="text-sm mt-1">Scan barcode or type product name above</p>
            </div>
          )}
        </div>
      </div>

      {/* ── RIGHT: Cart ─────────────────────────────────── */}
      <div className="w-80 xl:w-96 bg-surface-1 border-l border-white/5 flex flex-col">
        {/* Cart Header */}
        <div className="p-4 border-b border-white/5">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-white">Current Sale</h2>
            {cart.items.length > 0 && (
              <button
                onClick={() => cart.clearCart()}
                className="text-xs text-red-400/70 hover:text-red-400 transition-colors"
              >
                Clear all
              </button>
            )}
          </div>
          <p className="text-xs text-white/40 mt-0.5">{itemCount} item{itemCount !== 1 ? 's' : ''}</p>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {cart.items.length === 0 ? (
            <div className="text-center py-16 text-white/20">
              <MdReceipt size={36} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">Cart is empty</p>
            </div>
          ) : (
            cart.items.map((item) => (
              <CartItemRow
                key={item.product.id}
                item={item}
                onRemove={() => cart.removeItem(item.product.id)}
                onQtyChange={(q) => cart.updateQuantity(item.product.id, q)}
              />
            ))
          )}
        </div>

        {/* Totals & Checkout */}
        <div className="p-4 border-t border-white/5 space-y-3">
          {/* Discount input */}
          <div className="flex items-center gap-2">
            <MdLocalOffer className="text-white/30" size={16} />
            <input
              type="number"
              min="0"
              max="100"
              value={cart.globalDiscount || ''}
              onChange={(e) => cart.setGlobalDiscount(Number(e.target.value))}
              placeholder="Discount %"
              className="input-base flex-1 py-2 text-sm"
            />
          </div>

          {/* Totals */}
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between text-white/60">
              <span>Subtotal</span>
              <span className="font-mono">UGX {subtotal.toLocaleString()}</span>
            </div>
            {cart.globalDiscount > 0 && (
              <div className="flex justify-between text-accent-orange text-xs">
                <span>Discount ({cart.globalDiscount}%)</span>
                <span className="font-mono">-UGX {(subtotal * cart.globalDiscount / 100).toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-white font-semibold text-base pt-1.5 border-t border-white/10">
              <span>TOTAL</span>
              <span className="font-mono text-brand">UGX {total.toLocaleString()}</span>
            </div>
          </div>

          <button
            onClick={() => setShowCheckout(true)}
            disabled={cart.items.length === 0}
            className="btn-primary w-full py-3.5 text-base"
          >
            <MdPayment size={20} />
            Checkout
          </button>
        </div>
      </div>

      {/* ── Checkout Modal ─────────────────────────────── */}
      {showCheckout && (
        <CheckoutModal
          total={total}
          change={change}
          paymentMethod={cart.paymentMethod}
          amountPaid={cart.amountPaid}
          onPaymentMethodChange={cart.setPaymentMethod}
          onAmountPaidChange={cart.setAmountPaid}
          onConfirm={handleCheckout}
          onCancel={() => setShowCheckout(false)}
          processing={processingPayment}
        />
      )}

      {/* ── Receipt Modal ──────────────────────────────── */}
      {showReceipt && (
        <ReceiptModal
          sale={showReceipt}
          onClose={() => setShowReceipt(null)}
        />
      )}
    </div>
  );
}

// ─── Sub-components ──────────────────────────────────────

function ProductCard({ product, onAdd }: { product: Product; onAdd: () => void }) {
  const isLowStock = product.quantity <= product.minQuantity;
  const isOutOfStock = product.quantity === 0;

  return (
    <button
      onClick={onAdd}
      disabled={isOutOfStock}
      className={clsx(
        'pos-key text-left w-full p-3',
        isOutOfStock && 'opacity-40 cursor-not-allowed'
      )}
    >
      <p className="text-sm font-medium text-white truncate w-full">{product.name}</p>
      {product.localName && (
        <p className="text-xs text-white/40 truncate w-full">{product.localName}</p>
      )}
      <div className="flex items-center justify-between w-full mt-2">
        <span className="text-brand font-mono text-sm font-semibold">
          {product.sellingPrice.toLocaleString()}
        </span>
        <span
          className={clsx(
            'text-xs px-1.5 py-0.5 rounded-md font-medium',
            isOutOfStock ? 'bg-red-500/20 text-red-400' :
            isLowStock ? 'bg-accent-yellow/15 text-accent-yellow' :
            'bg-white/5 text-white/40'
          )}
        >
          {isOutOfStock ? 'Out' : `${product.quantity} ${product.unit}`}
        </span>
      </div>
    </button>
  );
}

function CartItemRow({ item, onRemove, onQtyChange }: {
  item: any; onRemove: () => void; onQtyChange: (q: number) => void;
}) {
  return (
    <div className="flex items-center gap-2 bg-surface-2 rounded-xl p-2.5 group">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">{item.product.name}</p>
        <p className="text-xs text-white/40 font-mono">
          UGX {item.product.sellingPrice.toLocaleString()} × {item.quantity}
        </p>
      </div>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onQtyChange(item.quantity - 1)}
          className="w-6 h-6 rounded-lg bg-surface-3 flex items-center justify-center text-white/60 hover:text-white transition-colors"
        >
          <MdRemove size={14} />
        </button>
        <span className="w-7 text-center text-sm font-mono text-white">{item.quantity}</span>
        <button
          onClick={() => onQtyChange(item.quantity + 1)}
          className="w-6 h-6 rounded-lg bg-surface-3 flex items-center justify-center text-white/60 hover:text-white transition-colors"
        >
          <MdAdd size={14} />
        </button>
      </div>
      <div className="text-right min-w-[60px]">
        <p className="text-sm font-mono font-semibold text-brand">
          {item.lineTotal.toLocaleString()}
        </p>
      </div>
      <button
        onClick={onRemove}
        className="opacity-0 group-hover:opacity-100 text-red-400/60 hover:text-red-400 transition-all"
      >
        <MdDelete size={16} />
      </button>
    </div>
  );
}

function CheckoutModal({ total, change, paymentMethod, amountPaid, onPaymentMethodChange,
  onAmountPaidChange, onConfirm, onCancel, processing }: any) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface-1 border border-white/10 rounded-2xl w-full max-w-md p-6 animate-in shadow-card">
        <h3 className="font-display text-xl font-bold mb-5">Complete Payment</h3>

        {/* Payment method */}
        <p className="text-sm text-white/60 mb-2">Payment Method</p>
        <div className="grid grid-cols-2 gap-2 mb-5">
          {PAYMENT_METHODS.map((m) => (
            <button
              key={m.id}
              onClick={() => onPaymentMethodChange(m.id)}
              className={clsx(
                'flex items-center gap-2 p-3 rounded-xl border text-sm font-medium transition-all',
                paymentMethod === m.id
                  ? 'bg-brand/15 border-brand/40 text-brand'
                  : 'bg-surface-2 border-white/10 text-white/60 hover:border-white/20'
              )}
            >
              <span>{m.icon}</span>
              {m.label}
              {paymentMethod === m.id && <MdCheck className="ml-auto text-brand" size={16} />}
            </button>
          ))}
        </div>

        {/* Total */}
        <div className="bg-surface-2 rounded-xl p-4 mb-4">
          <div className="flex justify-between text-white text-lg font-bold">
            <span>Total</span>
            <span className="font-mono text-brand">UGX {total.toLocaleString()}</span>
          </div>
        </div>

        {/* Amount paid (cash only) */}
        {paymentMethod === 'CASH' && (
          <div className="mb-4">
            <label className="block text-sm text-white/60 mb-1.5">Amount Received</label>
            <input
              type="number"
              value={amountPaid || ''}
              onChange={(e) => onAmountPaidChange(Number(e.target.value))}
              placeholder={`Min: ${total.toLocaleString()}`}
              className="input-base text-lg font-mono"
              autoFocus
            />
            {amountPaid > total && (
              <p className="mt-2 text-sm text-accent-green font-mono">
                Change: UGX {change.toLocaleString()}
              </p>
            )}
          </div>
        )}

        <div className="flex gap-3">
          <button onClick={onCancel} className="btn-secondary flex-1">Cancel</button>
          <button
            onClick={onConfirm}
            disabled={processing || (paymentMethod === 'CASH' && amountPaid < total)}
            className="btn-primary flex-1 py-3"
          >
            {processing ? (
              <div className="w-5 h-5 border-2 border-surface/30 border-t-surface rounded-full animate-spin mx-auto" />
            ) : (
              'Confirm Sale'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function ReceiptModal({ sale, onClose }: any) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface-1 border border-white/10 rounded-2xl w-full max-w-sm p-6 animate-in" id="receipt">
        <div className="text-center mb-4">
          <div className="w-12 h-12 bg-brand/20 rounded-full flex items-center justify-center mx-auto mb-3">
            <MdCheck className="text-brand" size={24} />
          </div>
          <h3 className="font-bold text-white text-lg">Sale Complete!</h3>
          {sale.receiptNumber && (
            <p className="text-xs text-white/40 mt-1 font-mono">{sale.receiptNumber}</p>
          )}
        </div>

        <div className="space-y-1 mb-4 text-sm">
          {sale.items?.map((item: any) => (
            <div key={item.id || item.productId} className="flex justify-between text-white/70">
              <span>{item.productName || item.product?.name} × {item.quantity}</span>
              <span className="font-mono">UGX {item.total.toLocaleString()}</span>
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 pt-3 space-y-1 text-sm">
          <div className="flex justify-between font-bold text-white">
            <span>TOTAL</span>
            <span className="font-mono text-brand">UGX {sale.total?.toLocaleString()}</span>
          </div>
          {sale.change > 0 && (
            <div className="flex justify-between text-accent-green text-xs">
              <span>Change</span>
              <span className="font-mono">UGX {sale.change?.toLocaleString()}</span>
            </div>
          )}
        </div>

        <div className="flex gap-3 mt-5">
          <button onClick={() => window.print()} className="btn-secondary flex-1 text-sm">
            🖨️ Print
          </button>
          <button onClick={onClose} className="btn-primary flex-1 text-sm">
            New Sale
          </button>
        </div>
      </div>
    </div>
  );
}
