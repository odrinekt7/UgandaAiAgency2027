// app/api/sales/route.ts — Sale creation and listing

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { sendLowStockAlert } from '@/lib/whatsapp';
import { format } from 'date-fns';
import { z } from 'zod';

const SaleItemSchema = z.object({
  productId: z.string(),
  quantity: z.number().int().positive(),
  unitPrice: z.number().positive(),
  discount: z.number().min(0).max(100).default(0),
});

const CreateSaleSchema = z.object({
  items: z.array(SaleItemSchema).min(1),
  paymentMethod: z.enum(['CASH', 'MTN_MOBILE_MONEY', 'AIRTEL_MONEY', 'CARD', 'BANK_TRANSFER', 'CREDIT']),
  amountPaid: z.number().min(0),
  discountAmount: z.number().min(0).default(0),
  mobileMoneyRef: z.string().optional(),
  notes: z.string().optional(),
  createdAt: z.string().optional(), // Allow offline sales to specify original time
});

// POST /api/sales — Create a new sale
export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const data = CreateSaleSchema.parse(body);

    // Fetch all products in one query
    const productIds = data.items.map((i) => i.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, businessId: user.businessId },
    });

    if (products.length !== productIds.length) {
      return NextResponse.json({ error: 'One or more products not found' }, { status: 404 });
    }

    // Validate stock levels
    for (const item of data.items) {
      const product = products.find((p) => p.id === item.productId)!;
      if (product.quantity < item.quantity) {
        return NextResponse.json(
          { error: `Insufficient stock for "${product.name}". Available: ${product.quantity}` },
          { status: 422 }
        );
      }
    }

    // Calculate totals
    const saleItems = data.items.map((item) => {
      const product = products.find((p) => p.id === item.productId)!;
      const lineTotal = item.quantity * item.unitPrice * (1 - item.discount / 100);
      return {
        productId: item.productId,
        productName: product.name,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        costPrice: product.costPrice,
        discount: item.discount,
        total: lineTotal,
      };
    });

    const subtotal = saleItems.reduce((sum, i) => sum + i.total, 0);
    const total = subtotal - data.discountAmount;
    const change = Math.max(0, data.amountPaid - total);

    // Generate receipt number: RCT-YYYYMMDD-XXXX
    const today = format(new Date(), 'yyyyMMdd');
    const count = await prisma.sale.count({
      where: {
        businessId: user.businessId,
        createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
      },
    });
    const receiptNumber = `RCT-${today}-${String(count + 1).padStart(4, '0')}`;

    // Run everything in a transaction for data integrity
    const sale = await prisma.$transaction(async (tx) => {
      // Create sale
      const newSale = await tx.sale.create({
        data: {
          businessId: user.businessId,
          cashierId: user.id,
          receiptNumber,
          subtotal,
          taxAmount: 0, // TODO: implement per-business tax
          discountAmount: data.discountAmount,
          total,
          amountPaid: data.amountPaid,
          change,
          paymentMethod: data.paymentMethod as any,
          mobileMoneyRef: data.mobileMoneyRef,
          notes: data.notes,
          createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
          items: { create: saleItems },
        },
        include: { items: true, cashier: { select: { name: true } } },
      });

      // Deduct stock for each item
      for (const item of data.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { quantity: { decrement: item.quantity } },
        });
      }

      return newSale;
    });

    // Check for low stock after sale (async, don't await)
    checkAndAlertLowStock(user.businessId, productIds).catch(console.error);

    return NextResponse.json({ data: sale }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 });
    }
    console.error('Sale create error:', error);
    return NextResponse.json({ error: 'Failed to process sale' }, { status: 500 });
  }
}

// GET /api/sales — List sales with filters
export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const startDate = searchParams.get('startDate');
  const endDate = searchParams.get('endDate');
  const cashierId = searchParams.get('cashierId');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  try {
    const where: any = { businessId: user.businessId };

    // Cashiers can only see their own sales
    if (user.role === 'CASHIER') {
      where.cashierId = user.id;
    } else if (cashierId) {
      where.cashierId = cashierId;
    }

    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate);
    }

    const [sales, total] = await Promise.all([
      prisma.sale.findMany({
        where,
        include: {
          cashier: { select: { name: true } },
          items: true,
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.sale.count({ where }),
    ]);

    return NextResponse.json({ data: sales, total, page, limit });
  } catch (error) {
    console.error('Sales GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch sales' }, { status: 500 });
  }
}

// ─── Helper: Check & send low stock alerts ────────────────
async function checkAndAlertLowStock(businessId: string, productIds: string[]) {
  const lowStockProducts = await prisma.product.findMany({
    where: {
      id: { in: productIds },
      businessId,
      // quantity <= minQuantity (raw SQL workaround)
    },
  });

  const truly_low = lowStockProducts.filter((p) => p.quantity <= p.minQuantity);
  if (truly_low.length === 0) return;

  const business = await prisma.business.findUnique({ where: { id: businessId } });
  if (!business?.whatsapp) return;

  // Create alerts in DB
  await prisma.stockAlert.createMany({
    data: truly_low.map((p) => ({
      businessId,
      productId: p.id,
      type: p.quantity === 0 ? ('OUT_OF_STOCK' as const) : ('LOW_STOCK' as const),
      message: `${p.name} is ${p.quantity === 0 ? 'OUT OF STOCK' : `low (${p.quantity} ${p.unit} left)`}`,
    })),
    skipDuplicates: true,
  });

  // Send WhatsApp alert
  await sendLowStockAlert({
    businessName: business.name,
    whatsappNumber: business.whatsapp,
    products: truly_low.map((p) => ({
      name: p.name,
      quantity: p.quantity,
      unit: p.unit,
      minQuantity: p.minQuantity,
    })),
  });
}
