// app/api/ai-search/route.ts — AI-powered product search

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { fuzzySearchProducts, aiSearchProducts } from '@/lib/openai';

export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { query } = await req.json();
    if (!query?.trim()) {
      return NextResponse.json({ data: [], suggestion: null });
    }

    // Fetch all active products for this business
    const products = await prisma.product.findMany({
      where: { businessId: user.businessId, isActive: true },
      select: {
        id: true, name: true, localName: true, barcode: true,
        sku: true, sellingPrice: true, quantity: true, unit: true,
        categoryId: true, businessId: true, costPrice: true,
        taxable: true, isActive: true, createdAt: true, updatedAt: true,
        minQuantity: true,
      },
    });

    // Step 1: Fast fuzzy search (no API cost)
    const fuzzyResults = fuzzySearchProducts(products as any, query);

    if (fuzzyResults.length > 0) {
      return NextResponse.json({
        data: fuzzyResults.slice(0, 10),
        suggestion: null,
        source: 'fuzzy',
      });
    }

    // Step 2: AI search only if fuzzy found nothing (costs tokens)
    const { matches, suggestion } = await aiSearchProducts(products as any, query);

    return NextResponse.json({
      data: matches,
      suggestion,
      source: 'ai',
    });
  } catch (error) {
    console.error('AI search error:', error);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
