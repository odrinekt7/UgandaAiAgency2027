// app/api/products/route.ts — Product CRUD

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const ProductSchema = z.object({
  name: z.string().min(1),
  localName: z.string().optional(),
  barcode: z.string().optional(),
  sku: z.string().optional(),
  categoryId: z.string().optional(),
  supplierId: z.string().optional(),
  costPrice: z.number().min(0),
  sellingPrice: z.number().min(0),
  quantity: z.number().int().min(0),
  minQuantity: z.number().int().min(0).default(5),
  unit: z.string().default('pcs'),
  taxable: z.boolean().default(false),
  description: z.string().optional(),
});

// GET /api/products — List all products for the business
export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search') || '';
  const categoryId = searchParams.get('categoryId');
  const lowStock = searchParams.get('lowStock') === 'true';
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '50');

  try {
    const where: any = {
      businessId: user.businessId,
      isActive: true,
    };

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { localName: { contains: search, mode: 'insensitive' } },
        { barcode: { contains: search } },
        { sku: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (categoryId) where.categoryId = categoryId;

    // Low stock filter: quantity <= minQuantity
    if (lowStock) {
      where.quantity = { lte: prisma.product.fields.minQuantity };
    }

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          category: { select: { id: true, name: true, color: true } },
          supplier: { select: { id: true, name: true } },
        },
        orderBy: { name: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.product.count({ where }),
    ]);

    return NextResponse.json({ data: products, total, page, limit });
  } catch (error) {
    console.error('Products GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}

// POST /api/products — Create new product
export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (user.role === 'CASHIER') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  try {
    const body = await req.json();
    const data = ProductSchema.parse(body);

    // Check for duplicate barcode
    if (data.barcode) {
      const exists = await prisma.product.findFirst({
        where: { barcode: data.barcode, businessId: user.businessId },
      });
      if (exists) {
        return NextResponse.json({ error: 'Barcode already exists' }, { status: 409 });
      }
    }

    const product = await prisma.product.create({
      data: { ...data, businessId: user.businessId },
      include: {
        category: { select: { id: true, name: true, color: true } },
      },
    });

    return NextResponse.json({ data: product }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 });
    }
    console.error('Product create error:', error);
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 });
  }
}
