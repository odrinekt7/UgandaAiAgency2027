// app/api/products/[id]/route.ts — Single product operations

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const UpdateProductSchema = z.object({
  name: z.string().min(1).optional(),
  localName: z.string().optional(),
  barcode: z.string().optional(),
  sku: z.string().optional(),
  categoryId: z.string().optional().nullable(),
  supplierId: z.string().optional().nullable(),
  costPrice: z.number().min(0).optional(),
  sellingPrice: z.number().min(0).optional(),
  quantity: z.number().int().min(0).optional(),
  minQuantity: z.number().int().min(0).optional(),
  unit: z.string().optional(),
  taxable: z.boolean().optional(),
  description: z.string().optional(),
  isActive: z.boolean().optional(),
});

// GET /api/products/:id
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const product = await prisma.product.findFirst({
    where: { id: params.id, businessId: user.businessId },
    include: {
      category: true,
      supplier: true,
    },
  });

  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ data: product });
}

// PUT /api/products/:id — Update product
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (user.role === 'CASHIER') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  try {
    const body = await req.json();
    const data = UpdateProductSchema.parse(body);

    // Verify ownership
    const existing = await prisma.product.findFirst({
      where: { id: params.id, businessId: user.businessId },
    });
    if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    // Check barcode uniqueness if changing
    if (data.barcode && data.barcode !== existing.barcode) {
      const dup = await prisma.product.findFirst({
        where: { barcode: data.barcode, businessId: user.businessId, id: { not: params.id } },
      });
      if (dup) return NextResponse.json({ error: 'Barcode already exists' }, { status: 409 });
    }

    const updated = await prisma.product.update({
      where: { id: params.id },
      data,
      include: { category: { select: { id: true, name: true, color: true } } },
    });

    return NextResponse.json({ data: updated });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 });
    }
    console.error('Product update error:', error);
    return NextResponse.json({ error: 'Update failed' }, { status: 500 });
  }
}

// DELETE /api/products/:id — Soft delete (set isActive = false)
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (user.role !== 'ADMIN') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const existing = await prisma.product.findFirst({
    where: { id: params.id, businessId: user.businessId },
  });
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  // Soft delete to preserve sales history
  await prisma.product.update({
    where: { id: params.id },
    data: { isActive: false },
  });

  return NextResponse.json({ message: 'Product deleted' });
}
