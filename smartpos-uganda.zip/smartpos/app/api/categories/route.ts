// app/api/categories/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const categories = await prisma.category.findMany({
    where: { businessId: user.businessId },
    include: { _count: { select: { products: true } } },
    orderBy: { name: 'asc' },
  });

  return NextResponse.json({ data: categories });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (user.role === 'CASHIER') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const { name, color } = await req.json();
  if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 });

  const category = await prisma.category.create({
    data: { businessId: user.businessId, name, color: color || '#00D4AA' },
  });

  return NextResponse.json({ data: category }, { status: 201 });
}
