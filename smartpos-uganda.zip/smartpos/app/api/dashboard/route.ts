// app/api/dashboard/route.ts — Dashboard analytics

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { startOfDay, endOfDay, startOfWeek, endOfWeek, subDays, format } from 'date-fns';

export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const now = new Date();
    const todayStart = startOfDay(now);
    const todayEnd = endOfDay(now);
    const weekStart = startOfWeek(now, { weekStartsOn: 1 }); // Monday
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

    // Run all queries in parallel
    const [
      todaySales,
      weekSales,
      lowStockCount,
      topProducts,
      cashierStats,
      paymentBreakdown,
      last7DaysSales,
    ] = await Promise.all([
      // Today's sales aggregation
      prisma.sale.aggregate({
        where: {
          businessId: user.businessId,
          createdAt: { gte: todayStart, lte: todayEnd },
          status: 'COMPLETED',
        },
        _sum: { total: true },
        _count: { id: true },
      }),

      // This week's sales
      prisma.sale.aggregate({
        where: {
          businessId: user.businessId,
          createdAt: { gte: weekStart, lte: weekEnd },
          status: 'COMPLETED',
        },
        _sum: { total: true },
        _count: { id: true },
      }),

      // Low stock product count
      prisma.$queryRaw<[{ count: bigint }]>`
        SELECT COUNT(*) as count FROM products 
        WHERE "businessId" = ${user.businessId} 
        AND "isActive" = true 
        AND quantity <= "minQuantity"
      `,

      // Top products today by quantity sold
      prisma.saleItem.groupBy({
        by: ['productId', 'productName'],
        where: {
          sale: {
            businessId: user.businessId,
            createdAt: { gte: todayStart, lte: todayEnd },
            status: 'COMPLETED',
          },
        },
        _sum: { quantity: true, total: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 5,
      }),

      // Cashier stats today
      prisma.sale.groupBy({
        by: ['cashierId'],
        where: {
          businessId: user.businessId,
          createdAt: { gte: todayStart, lte: todayEnd },
          status: 'COMPLETED',
        },
        _sum: { total: true },
        _count: { id: true },
      }),

      // Payment method breakdown today
      prisma.sale.groupBy({
        by: ['paymentMethod'],
        where: {
          businessId: user.businessId,
          createdAt: { gte: todayStart, lte: todayEnd },
          status: 'COMPLETED',
        },
        _sum: { total: true },
        _count: { id: true },
      }),

      // Last 7 days sales trend
      prisma.sale.findMany({
        where: {
          businessId: user.businessId,
          createdAt: { gte: subDays(now, 6) },
          status: 'COMPLETED',
        },
        select: { total: true, createdAt: true, items: { select: { total: true, costPrice: true, quantity: true } } },
      }),
    ]);

    // Calculate today's profit
    const todaySalesItems = await prisma.saleItem.findMany({
      where: {
        sale: {
          businessId: user.businessId,
          createdAt: { gte: todayStart, lte: todayEnd },
          status: 'COMPLETED',
        },
      },
      select: { total: true, costPrice: true, quantity: true },
    });

    const todayProfit = todaySalesItems.reduce(
      (sum, i) => sum + (i.total - i.costPrice * i.quantity),
      0
    );

    // Enrich cashier stats with names
    const cashierIds = cashierStats.map((c) => c.cashierId);
    const cashiers = await prisma.user.findMany({
      where: { id: { in: cashierIds } },
      select: { id: true, name: true },
    });

    const enrichedCashierStats = cashierStats.map((c) => ({
      name: cashiers.find((u) => u.id === c.cashierId)?.name || 'Unknown',
      sales: c._sum.total || 0,
      transactions: c._count.id,
    }));

    // Build 7-day trend
    const salesByDay = Array.from({ length: 7 }, (_, i) => {
      const day = subDays(now, 6 - i);
      const dayStr = format(day, 'yyyy-MM-dd');
      const daySales = last7DaysSales.filter(
        (s) => format(new Date(s.createdAt), 'yyyy-MM-dd') === dayStr
      );
      const revenue = daySales.reduce((sum, s) => sum + s.total, 0);
      const profit = daySales.reduce(
        (sum, s) =>
          sum +
          s.items.reduce((iSum, i) => iSum + (i.total - i.costPrice * i.quantity), 0),
        0
      );
      return { date: format(day, 'EEE'), sales: revenue, profit };
    });

    return NextResponse.json({
      data: {
        todaySales: todaySales._sum.total || 0,
        todayTransactions: todaySales._count.id || 0,
        todayProfit,
        weekSales: weekSales._sum.total || 0,
        weekTransactions: weekSales._count.id || 0,
        lowStockCount: Number((lowStockCount as any)[0]?.count || 0),
        topProducts: topProducts.map((p) => ({
          name: p.productName,
          quantity: p._sum.quantity || 0,
          revenue: p._sum.total || 0,
        })),
        cashierStats: enrichedCashierStats,
        paymentBreakdown: paymentBreakdown.map((p) => ({
          method: p.paymentMethod,
          amount: p._sum.total || 0,
          count: p._count.id,
        })),
        salesByDay,
      },
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return NextResponse.json({ error: 'Failed to load dashboard' }, { status: 500 });
  }
}
