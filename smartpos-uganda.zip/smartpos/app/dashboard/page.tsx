'use client';
// app/dashboard/page.tsx — Sales analytics dashboard

import { useEffect, useState } from 'react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import {
  MdTrendingUp, MdShoppingCart, MdInventory,
  MdAttachMoney, MdWarning, MdRefresh
} from 'react-icons/md';
import type { DashboardStats } from '@/types';
import { clsx } from 'clsx';

const PAYMENT_COLORS: Record<string, string> = {
  CASH: '#00D4AA',
  MTN_MOBILE_MONEY: '#FFB800',
  AIRTEL_MONEY: '#FF6B35',
  CARD: '#3B82F6',
  CREDIT: '#8B5CF6',
};

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const fetchDashboard = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      setStats(data.data);
      setLastRefresh(new Date());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchDashboard, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <DashboardSkeleton />;
  if (!stats) return null;

  return (
    <div className="p-6 space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-sm text-white/40 mt-0.5">
            Last updated: {lastRefresh.toLocaleTimeString()}
          </p>
        </div>
        <button onClick={fetchDashboard} className="btn-secondary flex items-center gap-2">
          <MdRefresh size={18} />
          Refresh
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          label="Today's Sales"
          value={`UGX ${stats.todaySales.toLocaleString()}`}
          sub={`${stats.todayTransactions} transactions`}
          icon={<MdAttachMoney size={20} />}
          color="brand"
        />
        <KPICard
          label="Today's Profit"
          value={`UGX ${stats.todayProfit.toLocaleString()}`}
          sub="Estimated gross"
          icon={<MdTrendingUp size={20} />}
          color="green"
        />
        <KPICard
          label="Week Sales"
          value={`UGX ${stats.weekSales.toLocaleString()}`}
          sub="This week total"
          icon={<MdShoppingCart size={20} />}
          color="blue"
        />
        <KPICard
          label="Low Stock"
          value={stats.lowStockCount.toString()}
          sub="Items need reorder"
          icon={<MdWarning size={20} />}
          color={stats.lowStockCount > 0 ? 'orange' : 'green'}
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* 7-day trend */}
        <div className="card p-5 lg:col-span-2">
          <h3 className="font-semibold text-white mb-4">7-Day Sales Trend</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={stats.salesByDay}>
              <defs>
                <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
                tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: '#1C2230', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 13 }}
                labelStyle={{ color: 'white' }}
                formatter={(v: any) => [`UGX ${v.toLocaleString()}`, undefined]}
              />
              <Area type="monotone" dataKey="sales" stroke="#00D4AA" strokeWidth={2}
                fill="url(#salesGrad)" name="Sales" />
              <Area type="monotone" dataKey="profit" stroke="#3B82F6" strokeWidth={2}
                fill="url(#profitGrad)" name="Profit" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Payment breakdown */}
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-4">Payment Methods</h3>
          {stats.paymentBreakdown.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={stats.paymentBreakdown} dataKey="amount" nameKey="method"
                    cx="50%" cy="50%" innerRadius={50} outerRadius={75} strokeWidth={0}>
                    {stats.paymentBreakdown.map((entry) => (
                      <Cell key={entry.method}
                        fill={PAYMENT_COLORS[entry.method] || '#666'} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: '#1C2230', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 12 }}
                    formatter={(v: any) => [`UGX ${v.toLocaleString()}`, undefined]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 mt-2">
                {stats.paymentBreakdown.map((p) => (
                  <div key={p.method} className="flex items-center gap-2 text-xs">
                    <div className="w-2.5 h-2.5 rounded-full"
                      style={{ background: PAYMENT_COLORS[p.method] || '#666' }} />
                    <span className="text-white/60 flex-1">
                      {p.method.replace('_', ' ')}
                    </span>
                    <span className="text-white/80 font-mono">
                      UGX {p.amount.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-10 text-white/30 text-sm">No sales today yet</div>
          )}
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top products */}
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-4">Top Products Today</h3>
          {stats.topProducts.length > 0 ? (
            <div className="space-y-3">
              {stats.topProducts.map((p, i) => (
                <div key={p.name} className="flex items-center gap-3">
                  <span className="text-xs text-white/30 w-5 font-mono">{i + 1}</span>
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-white/80">{p.name}</span>
                      <span className="text-white/50 font-mono">UGX {p.revenue.toLocaleString()}</span>
                    </div>
                    <div className="h-1.5 bg-surface-3 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-brand rounded-full"
                        style={{ width: `${(p.quantity / (stats.topProducts[0]?.quantity || 1)) * 100}%` }}
                      />
                    </div>
                  </div>
                  <span className="text-xs text-white/40 w-10 text-right">{p.quantity} sold</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-white/30 text-center py-8">No sales today yet</p>
          )}
        </div>

        {/* Cashier performance */}
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-4">Cashier Performance Today</h3>
          {stats.cashierStats.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={stats.cashierStats} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
                <XAxis type="number" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
                  tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="name" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }} width={80} />
                <Tooltip
                  contentStyle={{ background: '#1C2230', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 12 }}
                  formatter={(v: any) => [`UGX ${v.toLocaleString()}`, 'Sales']}
                />
                <Bar dataKey="sales" fill="#00D4AA" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-sm text-white/30 text-center py-8">No cashier data today</p>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── KPI Card ─────────────────────────────────────────────
const COLOR_MAP: any = {
  brand: { bg: 'bg-brand/10', text: 'text-brand', icon: 'text-brand' },
  green: { bg: 'bg-accent-green/10', text: 'text-accent-green', icon: 'text-accent-green' },
  blue: { bg: 'bg-accent-blue/10', text: 'text-accent-blue', icon: 'text-accent-blue' },
  orange: { bg: 'bg-accent-orange/10', text: 'text-accent-orange', icon: 'text-accent-orange' },
};

function KPICard({ label, value, sub, icon, color }: any) {
  const c = COLOR_MAP[color] || COLOR_MAP.brand;
  return (
    <div className="card p-5">
      <div className={clsx('w-10 h-10 rounded-xl flex items-center justify-center mb-3', c.bg)}>
        <span className={c.icon}>{icon}</span>
      </div>
      <p className={clsx('font-mono text-xl font-bold', c.text)}>{value}</p>
      <p className="text-sm text-white/80 font-medium mt-0.5">{label}</p>
      <p className="text-xs text-white/40 mt-0.5">{sub}</p>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="p-6 space-y-6 max-w-7xl animate-pulse">
      <div className="h-8 bg-surface-2 rounded-lg w-48" />
      <div className="grid grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="card p-5 h-32 bg-surface-2" />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-5">
        <div className="card h-64 col-span-2 bg-surface-2" />
        <div className="card h-64 bg-surface-2" />
      </div>
    </div>
  );
}
