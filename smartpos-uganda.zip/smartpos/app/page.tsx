'use client';
// app/page.tsx — Login page

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { MdStorefront, MdEmail, MdLock, MdArrowForward } from 'react-icons/md';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'Login failed');
        return;
      }

      toast.success(`Welcome back, ${data.user.name}!`);
      router.push('/pos');
    } catch {
      toast.error('Connection error. Check your internet.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface bg-grid flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="absolute inset-0 bg-glow-brand pointer-events-none" />

      <div className="w-full max-w-md animate-in">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-brand/15 rounded-2xl border border-brand/20 mb-5 glow-brand">
            <MdStorefront className="text-brand" size={32} />
          </div>
          <h1 className="font-display text-3xl font-bold text-white">SmartPOS</h1>
          <p className="text-white/40 text-sm mt-1.5">AI-powered retail for Uganda</p>
        </div>

        {/* Login Card */}
        <div className="card p-8 shadow-card">
          <h2 className="font-display text-xl font-semibold mb-6">Sign in to your store</h2>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm text-white/60 mb-1.5">Email address</label>
              <div className="relative">
                <MdEmail
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30"
                  size={18}
                />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@yourshop.com"
                  required
                  className="input-base pl-10"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm text-white/60 mb-1.5">Password</label>
              <div className="relative">
                <MdLock
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30"
                  size={18}
                />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="input-base pl-10"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-2 py-3 mt-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-surface/30 border-t-surface rounded-full animate-spin" />
              ) : (
                <>
                  Sign In
                  <MdArrowForward size={18} />
                </>
              )}
            </button>
          </form>

          {/* Demo credentials hint */}
          <div className="mt-6 p-3.5 bg-brand/5 border border-brand/15 rounded-xl">
            <p className="text-xs text-brand/70 font-medium mb-1">Demo Credentials</p>
            <p className="text-xs text-white/40">admin@demo.com / demo1234</p>
          </div>
        </div>

        <p className="text-center text-xs text-white/20 mt-6">
          SmartPOS Uganda · Powered by AI
        </p>
      </div>
    </div>
  );
}
