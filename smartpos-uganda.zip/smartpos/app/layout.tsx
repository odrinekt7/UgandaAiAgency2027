// app/layout.tsx — Root layout with PWA meta tags

import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'SmartPOS Uganda',
  description: 'AI-powered POS & Inventory Management for Uganda Businesses',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'SmartPOS',
  },
  formatDetection: { telephone: false },
  icons: {
    icon: '/icon-192.png',
    apple: '/apple-icon.png',
  },
};

export const viewport: Viewport = {
  themeColor: '#0D1117',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        {/* PWA Tags */}
        <link rel="manifest" href="/manifest.json" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="font-body bg-surface text-white">
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1C2230',
              color: '#E6EDF3',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: '12px',
              fontSize: '14px',
            },
            success: {
              iconTheme: { primary: '#00D4AA', secondary: '#0D1117' },
            },
            error: {
              iconTheme: { primary: '#EF4444', secondary: '#0D1117' },
            },
          }}
        />
      </body>
    </html>
  );
}
