// app/(app)/dashboard/page.tsx
// Re-exports the dashboard page component from its location

export { default } from '@/app/dashboard/page';
