// app/(app)/layout.tsx — Protected shell for all app pages
// All routes inside (app)/ require authentication

import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { verifyToken } from '@/lib/auth';
import { Sidebar } from '@/components/layout/Sidebar';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  // Server-side auth check
  const cookieStore = cookies();
  const token = cookieStore.get('smartpos_session')?.value;

  if (!token) redirect('/');

  const user = await verifyToken(token);
  if (!user) redirect('/');

  return (
    <div className="flex min-h-screen bg-surface bg-grid">
      {/* Fixed sidebar */}
      <Sidebar
        userRole={user.role}
        userName={user.name}
        businessName="My Store" // TODO: fetch from business context
      />

      {/* Main content — offset for sidebar */}
      <main className="flex-1 ml-60 min-h-screen overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
