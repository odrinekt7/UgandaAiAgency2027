'use client';
// app/(app)/inventory/page.tsx — Full inventory management

import { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { clsx } from 'clsx';
import {
  MdAdd, MdSearch, MdEdit, MdDelete, MdFilterList,
  MdWarning, MdInventory2, MdBarChart, MdUpload,
  MdClose, MdSave, MdRefresh
} from 'react-icons/md';
import type { Product } from '@/types';

// ─── Category color pills ────────────────────────────────
const UNITS = ['pcs', 'kg', 'g', 'litre', 'ml', 'box', 'dozen', 'bag', 'bottle', 'strip', 'sachet', 'roll'];

interface Category { id: string; name: string; color: string; }

export default function InventoryPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterLowStock, setFilterLowStock] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const LIMIT = 30;

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: String(LIMIT),
        ...(search && { search }),
        ...(filterCategory && { categoryId: filterCategory }),
        ...(filterLowStock && { lowStock: 'true' }),
      });
      const res = await fetch(`/api/products?${params}`);
      const data = await res.json();
      setProducts(data.data || []);
      setTotal(data.total || 0);
    } catch {
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  }, [page, search, filterCategory, filterLowStock]);

  const fetchCategories = async () => {
    try {
      const res = await fetch('/api/categories');
      const data = await res.json();
      setCategories(data.data || []);
    } catch {}
  };

  useEffect(() => { fetchProducts(); }, [fetchProducts]);
  useEffect(() => { fetchCategories(); }, []);

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Product deleted');
        fetchProducts();
      } else {
        toast.error('Delete failed');
      }
    } catch {
      toast.error('Connection error');
    }
  };

  const lowStockCount = products.filter(p => p.quantity <= p.minQuantity).length;

  return (
    <div className="p-6 max-w-7xl space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Inventory</h1>
          <p className="text-sm text-white/40 mt-0.5">{total} products total</p>
        </div>
        <div className="flex items-center gap-2">
          {lowStockCount > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 bg-accent-orange/10 border border-accent-orange/20 rounded-xl text-sm text-accent-orange">
              <MdWarning size={16} />
              {lowStockCount} low stock
            </div>
          )}
          <button
            onClick={() => { setEditProduct(null); setShowForm(true); }}
            className="btn-primary flex items-center gap-2"
          >
            <MdAdd size={18} />
            Add Product
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <MdSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" size={18} />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search products..."
            className="input-base pl-10"
          />
        </div>
        <select
          value={filterCategory}
          onChange={(e) => { setFilterCategory(e.target.value); setPage(1); }}
          className="input-base w-auto"
        >
          <option value="">All Categories</option>
          {categories.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <button
          onClick={() => { setFilterLowStock(!filterLowStock); setPage(1); }}
          className={clsx(
            'flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all',
            filterLowStock
              ? 'bg-accent-orange/15 border-accent-orange/40 text-accent-orange'
              : 'bg-surface-2 border-white/10 text-white/60 hover:border-white/20'
          )}
        >
          <MdFilterList size={16} />
          Low Stock
        </button>
        <button onClick={fetchProducts} className="btn-secondary flex items-center gap-2">
          <MdRefresh size={18} />
        </button>
      </div>

      {/* Products Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="table-header text-left">Product</th>
                <th className="table-header text-left">Category</th>
                <th className="table-header text-right">Cost</th>
                <th className="table-header text-right">Price</th>
                <th className="table-header text-right">Margin</th>
                <th className="table-header text-right">Stock</th>
                <th className="table-header text-center">Status</th>
                <th className="table-header text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [...Array(8)].map((_, i) => (
                  <tr key={i}>
                    {[...Array(8)].map((_, j) => (
                      <td key={j} className="table-cell">
                        <div className="h-4 bg-surface-3 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : products.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-16 text-white/30">
                    <MdInventory2 size={40} className="mx-auto mb-2 opacity-30" />
                    <p>No products found</p>
                  </td>
                </tr>
              ) : (
                products.map((product) => {
                  const margin = product.costPrice > 0
                    ? (((product.sellingPrice - product.costPrice) / product.sellingPrice) * 100).toFixed(0)
                    : '—';
                  const isLow = product.quantity <= product.minQuantity;
                  const isOut = product.quantity === 0;
                  return (
                    <tr key={product.id} className="hover:bg-white/2 transition-colors group">
                      <td className="table-cell">
                        <div>
                          <p className="font-medium text-white">{product.name}</p>
                          {product.localName && (
                            <p className="text-xs text-white/40">{product.localName}</p>
                          )}
                          {product.barcode && (
                            <p className="text-xs text-white/25 font-mono">{product.barcode}</p>
                          )}
                        </div>
                      </td>
                      <td className="table-cell">
                        {product.category ? (
                          <span
                            className="badge text-xs"
                            style={{
                              background: `${product.category.color}20`,
                              color: product.category.color,
                            }}
                          >
                            {product.category.name}
                          </span>
                        ) : (
                          <span className="text-white/30 text-xs">—</span>
                        )}
                      </td>
                      <td className="table-cell text-right font-mono text-white/60 text-xs">
                        {product.costPrice.toLocaleString()}
                      </td>
                      <td className="table-cell text-right font-mono font-semibold text-brand">
                        {product.sellingPrice.toLocaleString()}
                      </td>
                      <td className="table-cell text-right">
                        <span className={clsx(
                          'text-xs font-mono font-semibold',
                          Number(margin) >= 30 ? 'text-accent-green' :
                          Number(margin) >= 15 ? 'text-accent-yellow' : 'text-accent-orange'
                        )}>
                          {margin}%
                        </span>
                      </td>
                      <td className="table-cell text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <span className={clsx(
                            'font-mono text-sm font-semibold',
                            isOut ? 'text-red-400' : isLow ? 'text-accent-yellow' : 'text-white/80'
                          )}>
                            {product.quantity}
                          </span>
                          <span className="text-white/30 text-xs">{product.unit}</span>
                        </div>
                      </td>
                      <td className="table-cell text-center">
                        <span className={clsx('badge', {
                          'bg-red-500/15 text-red-400': isOut,
                          'bg-accent-yellow/15 text-accent-yellow': isLow && !isOut,
                          'bg-accent-green/10 text-accent-green': !isLow && !isOut,
                        })}>
                          {isOut ? 'Out of Stock' : isLow ? 'Low Stock' : 'In Stock'}
                        </span>
                      </td>
                      <td className="table-cell text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => { setEditProduct(product); setShowForm(true); }}
                            className="w-8 h-8 rounded-lg bg-surface-3 hover:bg-brand/20 hover:text-brand text-white/50 flex items-center justify-center transition-all"
                          >
                            <MdEdit size={15} />
                          </button>
                          <button
                            onClick={() => handleDelete(product.id, product.name)}
                            className="w-8 h-8 rounded-lg bg-surface-3 hover:bg-red-500/20 hover:text-red-400 text-white/50 flex items-center justify-center transition-all"
                          >
                            <MdDelete size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > LIMIT && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-white/5">
            <p className="text-sm text-white/40">
              Showing {((page - 1) * LIMIT) + 1}–{Math.min(page * LIMIT, total)} of {total}
            </p>
            <div className="flex gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="btn-secondary py-1.5 px-3 text-xs disabled:opacity-30"
              >← Prev</button>
              <button
                disabled={page * LIMIT >= total}
                onClick={() => setPage(p => p + 1)}
                className="btn-secondary py-1.5 px-3 text-xs disabled:opacity-30"
              >Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Product Form Modal */}
      {showForm && (
        <ProductFormModal
          product={editProduct}
          categories={categories}
          onClose={() => { setShowForm(false); setEditProduct(null); }}
          onSaved={() => { setShowForm(false); setEditProduct(null); fetchProducts(); }}
        />
      )}
    </div>
  );
}

// ─── Product Form Modal ──────────────────────────────────
interface ProductFormProps {
  product: Product | null;
  categories: Category[];
  onClose: () => void;
  onSaved: () => void;
}

function ProductFormModal({ product, categories, onClose, onSaved }: ProductFormProps) {
  const isEdit = !!product;
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: product?.name || '',
    localName: product?.localName || '',
    barcode: product?.barcode || '',
    sku: product?.sku || '',
    categoryId: product?.categoryId || '',
    costPrice: product?.costPrice || 0,
    sellingPrice: product?.sellingPrice || 0,
    quantity: product?.quantity || 0,
    minQuantity: product?.minQuantity || 5,
    unit: product?.unit || 'pcs',
    taxable: product?.taxable || false,
    description: product?.description || '',
  });

  const margin = form.sellingPrice > 0 && form.costPrice > 0
    ? (((form.sellingPrice - form.costPrice) / form.sellingPrice) * 100).toFixed(1)
    : null;

  const set = (key: string, val: any) => setForm(f => ({ ...f, [key]: val }));

  const handleSave = async () => {
    if (!form.name || !form.sellingPrice) {
      toast.error('Name and selling price are required');
      return;
    }
    setSaving(true);
    try {
      const url = isEdit ? `/api/products/${product!.id}` : '/api/products';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || 'Save failed');
        return;
      }
      toast.success(isEdit ? 'Product updated' : 'Product created');
      onSaved();
    } catch {
      toast.error('Connection error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-surface-1 border border-white/10 rounded-2xl w-full max-w-lg my-auto shadow-card animate-in">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/5">
          <h3 className="font-display text-lg font-bold">
            {isEdit ? 'Edit Product' : 'Add New Product'}
          </h3>
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
            <MdClose size={20} />
          </button>
        </div>

        {/* Form */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="form-label">Product Name *</label>
              <input value={form.name} onChange={e => set('name', e.target.value)}
                placeholder="e.g. Sugar 2kg" className="input-base" />
            </div>
            <div>
              <label className="form-label">Local Name <span className="text-white/30">(optional)</span></label>
              <input value={form.localName} onChange={e => set('localName', e.target.value)}
                placeholder="e.g. Sukari" className="input-base" />
            </div>
            <div>
              <label className="form-label">Barcode</label>
              <input value={form.barcode} onChange={e => set('barcode', e.target.value)}
                placeholder="Scan or type" className="input-base font-mono" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Category</label>
              <select value={form.categoryId} onChange={e => set('categoryId', e.target.value)}
                className="input-base">
                <option value="">No category</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Unit</label>
              <select value={form.unit} onChange={e => set('unit', e.target.value)}
                className="input-base">
                {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="form-label">Cost Price (UGX)</label>
              <input type="number" min="0" value={form.costPrice}
                onChange={e => set('costPrice', Number(e.target.value))}
                className="input-base font-mono" />
            </div>
            <div>
              <label className="form-label">Selling Price (UGX) *</label>
              <input type="number" min="0" value={form.sellingPrice}
                onChange={e => set('sellingPrice', Number(e.target.value))}
                className="input-base font-mono" />
            </div>
            <div className="flex flex-col justify-end pb-0.5">
              {margin && (
                <div className="input-base text-center">
                  <p className="text-xs text-white/40">Margin</p>
                  <p className={clsx('font-mono font-bold text-sm', Number(margin) >= 30 ? 'text-accent-green' : 'text-accent-yellow')}>
                    {margin}%
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Current Stock</label>
              <input type="number" min="0" value={form.quantity}
                onChange={e => set('quantity', Number(e.target.value))}
                className="input-base font-mono" />
            </div>
            <div>
              <label className="form-label">Low Stock Alert At</label>
              <input type="number" min="0" value={form.minQuantity}
                onChange={e => set('minQuantity', Number(e.target.value))}
                className="input-base font-mono" />
            </div>
          </div>

          <div>
            <label className="form-label">Description <span className="text-white/30">(optional)</span></label>
            <textarea value={form.description} onChange={e => set('description', e.target.value)}
              rows={2} placeholder="Product description..."
              className="input-base resize-none" />
          </div>

          <label className="flex items-center gap-3 cursor-pointer">
            <div className={clsx(
              'w-10 h-5 rounded-full transition-colors relative',
              form.taxable ? 'bg-brand' : 'bg-surface-3'
            )}>
              <div className={clsx(
                'absolute top-0.5 w-4 h-4 bg-white rounded-full transition-transform shadow-sm',
                form.taxable ? 'translate-x-5' : 'translate-x-0.5'
              )} />
            </div>
            <input type="checkbox" checked={form.taxable}
              onChange={e => set('taxable', e.target.checked)} className="sr-only" />
            <span className="text-sm text-white/70">Taxable item</span>
          </label>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-5 border-t border-white/5">
          <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
            {saving ? (
              <div className="w-4 h-4 border-2 border-surface/30 border-t-surface rounded-full animate-spin" />
            ) : (
              <><MdSave size={16} />{isEdit ? 'Update' : 'Create'}</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
