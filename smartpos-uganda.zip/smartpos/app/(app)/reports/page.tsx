'use client';
// app/(app)/reports/page.tsx — Sales reports with date filtering

import { useState, useEffect } from 'react';
import { format, subDays, startOfMonth, endOfMonth, startOfWeek, endOfWeek } from 'date-fns';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { MdDownload, MdCalendarMonth, MdTrendingUp, MdReceipt } from 'react-icons/md';
import { clsx } from 'clsx';
import toast from 'react-hot-toast';

type DateRange = 'today' | 'week' | 'month' | 'custom';

const PAYMENT_LABELS: Record<string, string> = {
  CASH: 'Cash',
  MTN_MOBILE_MONEY: 'MTN MoMo',
  AIRTEL_MONEY: 'Airtel Money',
  CARD: 'Card',
  CREDIT: 'Credit',
};

export default function ReportsPage() {
  const [range, setRange] = useState<DateRange>('week');
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 6), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0, transactions: 0, profit: 0, avgTransaction: 0
  });

  const applyRange = (r: DateRange) => {
    setRange(r);
    const now = new Date();
    switch (r) {
      case 'today':
        setStartDate(format(now, 'yyyy-MM-dd'));
        setEndDate(format(now, 'yyyy-MM-dd'));
        break;
      case 'week':
        setStartDate(format(startOfWeek(now, { weekStartsOn: 1 }), 'yyyy-MM-dd'));
        setEndDate(format(endOfWeek(now, { weekStartsOn: 1 }), 'yyyy-MM-dd'));
        break;
      case 'month':
        setStartDate(format(startOfMonth(now), 'yyyy-MM-dd'));
        setEndDate(format(endOfMonth(now), 'yyyy-MM-dd'));
        break;
    }
  };

  const fetchSales = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        startDate: `${startDate}T00:00:00.000Z`,
        endDate: `${endDate}T23:59:59.999Z`,
        limit: '500',
      });
      const res = await fetch(`/api/sales?${params}`);
      const data = await res.json();
      const salesData: any[] = data.data || [];
      setSales(salesData);

      // Compute stats
      const total = salesData.reduce((s, x) => s + x.total, 0);
      const profit = salesData.reduce((s, x) =>
        s + x.items.reduce((ii: number, i: any) => ii + (i.total - i.costPrice * i.quantity), 0), 0);
      setStats({
        total,
        transactions: salesData.length,
        profit,
        avgTransaction: salesData.length ? total / salesData.length : 0,
      });
    } catch {
      toast.error('Failed to load sales data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSales(); }, [startDate, endDate]);

  // Group sales by day for chart
  const salesByDay = (() => {
    const map: Record<string, { date: string; sales: number; profit: number; count: number }> = {};
    sales.forEach(s => {
      const d = format(new Date(s.createdAt), 'MMM d');
      if (!map[d]) map[d] = { date: d, sales: 0, profit: 0, count: 0 };
      map[d].sales += s.total;
      map[d].count += 1;
      map[d].profit += s.items?.reduce((ii: number, i: any) =>
        ii + (i.total - i.costPrice * i.quantity), 0) || 0;
    });
    return Object.values(map);
  })();

  // Payment breakdown
  const paymentBreakdown = (() => {
    const map: Record<string, { method: string; amount: number; count: number }> = {};
    sales.forEach(s => {
      if (!map[s.paymentMethod]) map[s.paymentMethod] = { method: s.paymentMethod, amount: 0, count: 0 };
      map[s.paymentMethod].amount += s.total;
      map[s.paymentMethod].count += 1;
    });
    return Object.values(map).sort((a, b) => b.amount - a.amount);
  })();

  // Top products
  const topProducts = (() => {
    const map: Record<string, { name: string; qty: number; revenue: number }> = {};
    sales.forEach(s => s.items?.forEach((i: any) => {
      if (!map[i.productName]) map[i.productName] = { name: i.productName, qty: 0, revenue: 0 };
      map[i.productName].qty += i.quantity;
      map[i.productName].revenue += i.total;
    }));
    return Object.values(map).sort((a, b) => b.revenue - a.revenue).slice(0, 10);
  })();

  const exportCSV = () => {
    const rows = [
      ['Receipt', 'Date', 'Cashier', 'Items', 'Total', 'Payment'],
      ...sales.map(s => [
        s.receiptNumber,
        format(new Date(s.createdAt), 'yyyy-MM-dd HH:mm'),
        s.cashier?.name || '',
        s.items?.length || 0,
        s.total,
        PAYMENT_LABELS[s.paymentMethod] || s.paymentMethod,
      ])
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales-${startDate}-to-${endDate}.csv`;
    a.click();
    toast.success('CSV downloaded');
  };

  return (
    <div className="p-6 max-w-7xl space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Sales Reports</h1>
          <p className="text-sm text-white/40 mt-0.5">
            {startDate === endDate ? format(new Date(startDate), 'MMM d, yyyy')
              : `${format(new Date(startDate), 'MMM d')} – ${format(new Date(endDate), 'MMM d, yyyy')}`}
          </p>
        </div>
        <button onClick={exportCSV} className="btn-secondary flex items-center gap-2">
          <MdDownload size={18} />
          Export CSV
        </button>
      </div>

      {/* Date Range Controls */}
      <div className="flex flex-wrap gap-2 items-center">
        {(['today', 'week', 'month', 'custom'] as DateRange[]).map(r => (
          <button key={r} onClick={() => applyRange(r)}
            className={clsx(
              'px-4 py-2 rounded-xl text-sm font-medium capitalize transition-all',
              range === r
                ? 'bg-brand text-surface font-semibold'
                : 'bg-surface-2 text-white/60 hover:text-white border border-white/10'
            )}>
            {r}
          </button>
        ))}
        {range === 'custom' && (
          <div className="flex items-center gap-2">
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
              className="input-base w-auto text-sm" />
            <span className="text-white/40 text-sm">to</span>
            <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
              className="input-base w-auto text-sm" />
          </div>
        )}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Revenue', value: `UGX ${stats.total.toLocaleString()}`, icon: '💰', color: 'text-brand' },
          { label: 'Gross Profit', value: `UGX ${stats.profit.toLocaleString()}`, icon: '📈', color: 'text-accent-green' },
          { label: 'Transactions', value: stats.transactions.toString(), icon: '🧾', color: 'text-accent-blue' },
          { label: 'Avg. Sale', value: `UGX ${Math.round(stats.avgTransaction).toLocaleString()}`, icon: '📊', color: 'text-accent-yellow' },
        ].map(k => (
          <div key={k.label} className="card p-5">
            <p className="text-2xl mb-1">{k.icon}</p>
            <p className={clsx('font-mono text-xl font-bold', k.color)}>{k.value}</p>
            <p className="text-sm text-white/50 mt-0.5">{k.label}</p>
          </div>
        ))}
      </div>

      {/* Sales trend chart */}
      <div className="card p-5">
        <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
          <MdTrendingUp className="text-brand" /> Revenue Trend
        </h3>
        {salesByDay.length > 0 ? (
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={salesByDay}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }}
                tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip contentStyle={{ background: '#1C2230', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 13 }}
                formatter={(v: any) => [`UGX ${v.toLocaleString()}`, undefined]} />
              <Area type="monotone" dataKey="sales" stroke="#00D4AA" strokeWidth={2}
                fill="url(#revGrad)" name="Revenue" />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="text-center py-16 text-white/30 text-sm">No sales data for this period</div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Top products */}
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-4">Top Products</h3>
          {topProducts.length > 0 ? (
            <div className="space-y-2.5">
              {topProducts.map((p, i) => (
                <div key={p.name} className="flex items-center gap-3">
                  <span className="text-xs text-white/30 w-5 font-mono text-center">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-white/80 truncate">{p.name}</span>
                      <span className="text-white/40 font-mono text-xs shrink-0 ml-2">
                        UGX {p.revenue.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-1 bg-surface-3 rounded-full">
                      <div className="h-full bg-gradient-to-r from-brand to-brand/60 rounded-full"
                        style={{ width: `${(p.revenue / (topProducts[0]?.revenue || 1)) * 100}%` }} />
                    </div>
                  </div>
                  <span className="text-xs text-white/30 w-12 text-right">{p.qty} sold</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-white/30 text-center py-8">No product data</p>
          )}
        </div>

        {/* Payment breakdown */}
        <div className="card p-5">
          <h3 className="font-semibold text-white mb-4">Payment Methods</h3>
          {paymentBreakdown.length > 0 ? (
            <div className="space-y-3">
              {paymentBreakdown.map(p => (
                <div key={p.method}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-white/70">{PAYMENT_LABELS[p.method] || p.method}</span>
                    <div className="flex gap-3">
                      <span className="text-white/40 text-xs">{p.count} txns</span>
                      <span className="font-mono font-medium text-white/80">
                        UGX {p.amount.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <div className="h-2 bg-surface-3 rounded-full overflow-hidden">
                    <div className="h-full bg-brand/70 rounded-full transition-all"
                      style={{ width: `${(p.amount / (stats.total || 1)) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-white/30 text-center py-8">No payment data</p>
          )}
        </div>
      </div>

      {/* Sales Table */}
      <div className="card overflow-hidden">
        <div className="p-4 border-b border-white/5 flex items-center gap-2">
          <MdReceipt className="text-brand" size={18} />
          <h3 className="font-semibold text-white">Transaction History</h3>
          <span className="text-xs text-white/40 ml-auto">{sales.length} records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="table-header text-left">Receipt #</th>
                <th className="table-header text-left">Time</th>
                <th className="table-header text-left">Cashier</th>
                <th className="table-header text-right">Items</th>
                <th className="table-header text-right">Total</th>
                <th className="table-header text-left">Payment</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i}>
                    {[...Array(6)].map((_, j) => (
                      <td key={j} className="table-cell">
                        <div className="h-4 bg-surface-3 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : sales.slice(0, 50).map(sale => (
                <tr key={sale.id} className="hover:bg-white/2 transition-colors">
                  <td className="table-cell font-mono text-brand text-xs">{sale.receiptNumber}</td>
                  <td className="table-cell text-white/60 text-xs">
                    {format(new Date(sale.createdAt), 'MMM d, HH:mm')}
                  </td>
                  <td className="table-cell text-white/70">{sale.cashier?.name}</td>
                  <td className="table-cell text-right text-white/60">{sale.items?.length}</td>
                  <td className="table-cell text-right font-mono font-semibold text-white">
                    {sale.total.toLocaleString()}
                  </td>
                  <td className="table-cell">
                    <span className="badge bg-brand/10 text-brand text-xs">
                      {PAYMENT_LABELS[sale.paymentMethod] || sale.paymentMethod}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
