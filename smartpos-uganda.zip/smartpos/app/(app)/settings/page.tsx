'use client';
// app/(app)/settings/page.tsx — Admin settings

import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { clsx } from 'clsx';
import {
  MdBusiness, MdPerson, MdCategory, MdWhatsapp,
  MdSave, MdAdd, MdDelete, MdVpnKey, MdCheck
} from 'react-icons/md';

type Tab = 'business' | 'users' | 'categories' | 'whatsapp';

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>('business');

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'business', label: 'Business', icon: <MdBusiness size={18} /> },
    { id: 'users', label: 'Users', icon: <MdPerson size={18} /> },
    { id: 'categories', label: 'Categories', icon: <MdCategory size={18} /> },
    { id: 'whatsapp', label: 'WhatsApp', icon: <MdWhatsapp size={18} /> },
  ];

  return (
    <div className="p-6 max-w-4xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Settings</h1>
        <p className="text-sm text-white/40 mt-0.5">Manage your store configuration</p>
      </div>

      <div className="flex gap-1 bg-surface-2 p-1 rounded-xl border border-white/5 w-fit">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={clsx(
              'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
              tab === t.id
                ? 'bg-surface text-white shadow-sm'
                : 'text-white/50 hover:text-white'
            )}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      <div className="animate-in">
        {tab === 'business' && <BusinessSettings />}
        {tab === 'users' && <UsersSettings />}
        {tab === 'categories' && <CategoriesSettings />}
        {tab === 'whatsapp' && <WhatsAppSettings />}
      </div>
    </div>
  );
}

// ─── Business Settings ───────────────────────────────────
function BusinessSettings() {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '', type: 'RETAIL', phone: '', address: '',
    currency: 'UGX', taxRate: 0, receiptFooter: 'Thank you for shopping with us!',
  });

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/settings/business', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) toast.success('Business settings saved');
      else toast.error('Save failed');
    } finally { setSaving(false); }
  };

  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const BUSINESS_TYPES = [
    { value: 'RETAIL', label: 'Mini Supermarket / Retail' },
    { value: 'PHARMACY', label: 'Pharmacy / Drug Shop' },
    { value: 'HARDWARE', label: 'Hardware Shop' },
    { value: 'BOUTIQUE', label: 'Boutique / Clothing' },
    { value: 'WHOLESALE', label: 'Wholesaler / Distributor' },
    { value: 'OTHER', label: 'Other' },
  ];

  return (
    <div className="card p-6 space-y-5">
      <h3 className="font-semibold text-white">Business Information</h3>
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <label className="form-label">Business Name</label>
          <input value={form.name} onChange={e => set('name', e.target.value)}
            placeholder="e.g. Nakato General Store" className="input-base" />
        </div>
        <div>
          <label className="form-label">Business Type</label>
          <select value={form.type} onChange={e => set('type', e.target.value)} className="input-base">
            {BUSINESS_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className="form-label">Phone Number</label>
          <input value={form.phone} onChange={e => set('phone', e.target.value)}
            placeholder="+256 700 000000" className="input-base" />
        </div>
        <div className="col-span-2">
          <label className="form-label">Address</label>
          <input value={form.address} onChange={e => set('address', e.target.value)}
            placeholder="Shop location" className="input-base" />
        </div>
        <div>
          <label className="form-label">Currency</label>
          <select value={form.currency} onChange={e => set('currency', e.target.value)} className="input-base">
            <option value="UGX">UGX — Ugandan Shilling</option>
            <option value="KES">KES — Kenyan Shilling</option>
            <option value="USD">USD — US Dollar</option>
          </select>
        </div>
        <div>
          <label className="form-label">Tax Rate (%)</label>
          <input type="number" min="0" max="100" step="0.5"
            value={form.taxRate} onChange={e => set('taxRate', Number(e.target.value))}
            className="input-base font-mono" />
        </div>
        <div className="col-span-2">
          <label className="form-label">Receipt Footer Message</label>
          <input value={form.receiptFooter} onChange={e => set('receiptFooter', e.target.value)}
            placeholder="Thank you for shopping with us!" className="input-base" />
        </div>
      </div>
      <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2">
        {saving ? <div className="w-4 h-4 border-2 border-surface/30 border-t-surface rounded-full animate-spin" /> : <MdSave size={16} />}
        Save Changes
      </button>
    </div>
  );
}

// ─── Users Settings ──────────────────────────────────────
function UsersSettings() {
  const [users, setUsers] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'CASHIER' });
  const [saving, setSaving] = useState(false);

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/users');
      const data = await res.json();
      setUsers(data.data || []);
    } catch {}
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      toast.error('Fill all fields');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser),
      });
      if (res.ok) {
        toast.success('User created');
        setShowAdd(false);
        setNewUser({ name: '', email: '', password: '', role: 'CASHIER' });
        fetchUsers();
      } else {
        const data = await res.json();
        toast.error(data.error || 'Failed to create user');
      }
    } finally { setSaving(false); }
  };

  const ROLE_COLORS: Record<string, string> = {
    ADMIN: 'bg-brand/15 text-brand',
    MANAGER: 'bg-accent-blue/15 text-accent-blue',
    CASHIER: 'bg-white/10 text-white/60',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-white/40">{users.length} team members</p>
        <button onClick={() => setShowAdd(!showAdd)} className="btn-primary flex items-center gap-2 text-sm">
          <MdAdd size={16} />Add User
        </button>
      </div>

      {showAdd && (
        <div className="card p-5 space-y-3 border border-brand/20">
          <h4 className="font-medium text-white">New User</h4>
          <div className="grid grid-cols-2 gap-3">
            <input value={newUser.name} onChange={e => setNewUser(u => ({ ...u, name: e.target.value }))}
              placeholder="Full name" className="input-base" />
            <input value={newUser.email} onChange={e => setNewUser(u => ({ ...u, email: e.target.value }))}
              placeholder="Email address" type="email" className="input-base" />
            <input value={newUser.password} onChange={e => setNewUser(u => ({ ...u, password: e.target.value }))}
              placeholder="Password (min 6 chars)" type="password" className="input-base" />
            <select value={newUser.role} onChange={e => setNewUser(u => ({ ...u, role: e.target.value }))}
              className="input-base">
              <option value="CASHIER">Cashier</option>
              <option value="MANAGER">Manager</option>
              <option value="ADMIN">Admin</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowAdd(false)} className="btn-secondary text-sm">Cancel</button>
            <button onClick={handleAddUser} disabled={saving} className="btn-primary text-sm">
              {saving ? 'Creating...' : 'Create User'}
            </button>
          </div>
        </div>
      )}

      <div className="card divide-y divide-white/5">
        {users.map(u => (
          <div key={u.id} className="flex items-center gap-4 p-4">
            <div className="w-9 h-9 rounded-full bg-surface-3 flex items-center justify-center text-white/60 font-bold">
              {u.name[0]?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white">{u.name}</p>
              <p className="text-xs text-white/40">{u.email}</p>
            </div>
            <span className={clsx('badge text-xs', ROLE_COLORS[u.role] || 'bg-white/10 text-white/50')}>
              {u.role}
            </span>
            <span className={clsx('w-2 h-2 rounded-full', u.isActive ? 'bg-accent-green' : 'bg-red-400')} />
          </div>
        ))}
        {users.length === 0 && (
          <div className="p-8 text-center text-white/30 text-sm">No users found</div>
        )}
      </div>
    </div>
  );
}

// ─── Categories Settings ─────────────────────────────────
const PRESET_COLORS = ['#00D4AA', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];

function CategoriesSettings() {
  const [categories, setCategories] = useState<any[]>([]);
  const [newCat, setNewCat] = useState({ name: '', color: PRESET_COLORS[0] });
  const [saving, setSaving] = useState(false);

  const fetchCats = async () => {
    try {
      const res = await fetch('/api/categories');
      const data = await res.json();
      setCategories(data.data || []);
    } catch {}
  };

  useEffect(() => { fetchCats(); }, []);

  const handleAdd = async () => {
    if (!newCat.name) { toast.error('Category name required'); return; }
    setSaving(true);
    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCat),
      });
      if (res.ok) {
        toast.success('Category added');
        setNewCat({ name: '', color: PRESET_COLORS[0] });
        fetchCats();
      }
    } finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this category?')) return;
    await fetch(`/api/categories/${id}`, { method: 'DELETE' });
    fetchCats();
  };

  return (
    <div className="space-y-4">
      <div className="card p-5 space-y-3">
        <h4 className="font-medium text-white">Add Category</h4>
        <div className="flex gap-3">
          <input value={newCat.name} onChange={e => setNewCat(c => ({ ...c, name: e.target.value }))}
            placeholder="e.g. Beverages, Medicines, Electronics" className="input-base flex-1" />
          <button onClick={handleAdd} disabled={saving} className="btn-primary px-4 whitespace-nowrap">
            <MdAdd size={18} />
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {PRESET_COLORS.map(c => (
            <button key={c} onClick={() => setNewCat(n => ({ ...n, color: c }))}
              className={clsx(
                'w-7 h-7 rounded-full transition-all border-2',
                newCat.color === c ? 'border-white scale-110' : 'border-transparent'
              )}
              style={{ background: c }} />
          ))}
        </div>
      </div>

      <div className="card divide-y divide-white/5">
        {categories.map(c => (
          <div key={c.id} className="flex items-center gap-3 p-3.5">
            <div className="w-4 h-4 rounded-full" style={{ background: c.color }} />
            <span className="text-sm text-white flex-1">{c.name}</span>
            <span className="text-xs text-white/30 font-mono">{c._count?.products || 0} products</span>
            <button onClick={() => handleDelete(c.id)} className="text-red-400/50 hover:text-red-400 transition-colors">
              <MdDelete size={16} />
            </button>
          </div>
        ))}
        {categories.length === 0 && (
          <div className="p-8 text-center text-white/30 text-sm">No categories yet</div>
        )}
      </div>
    </div>
  );
}

// ─── WhatsApp Settings ───────────────────────────────────
function WhatsAppSettings() {
  const [config, setConfig] = useState({
    whatsapp: '',
    lowStockAlerts: true,
    dailyReports: true,
    dailyReportTime: '20:00',
  });
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleTest = async () => {
    if (!config.whatsapp) { toast.error('Enter WhatsApp number first'); return; }
    setTesting(true);
    try {
      const res = await fetch('/api/webhooks/whatsapp/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: config.whatsapp }),
      });
      if (res.ok) toast.success('Test message sent! Check WhatsApp');
      else toast.error('Test failed — check your Make.com webhook setup');
    } finally { setTesting(false); }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/settings/whatsapp', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      if (res.ok) toast.success('WhatsApp settings saved');
      else toast.error('Save failed');
    } finally { setSaving(false); }
  };

  return (
    <div className="card p-6 space-y-5">
      <div>
        <h3 className="font-semibold text-white mb-1">WhatsApp Notifications</h3>
        <p className="text-sm text-white/40">Receive alerts and reports via WhatsApp (powered by Make.com)</p>
      </div>

      <div>
        <label className="form-label">WhatsApp Number</label>
        <input value={config.whatsapp} onChange={e => setConfig(c => ({ ...c, whatsapp: e.target.value }))}
          placeholder="+256700000000" className="input-base font-mono" />
        <p className="text-xs text-white/30 mt-1.5">Include country code (e.g. +256 for Uganda)</p>
      </div>

      <div className="space-y-3">
        {[
          { key: 'lowStockAlerts', label: 'Low Stock Alerts', desc: 'Get notified when products run low' },
          { key: 'dailyReports', label: 'Daily Sales Reports', desc: 'Receive daily summary each evening' },
        ].map(item => (
          <div key={item.key} className="flex items-center justify-between p-4 bg-surface-2 rounded-xl">
            <div>
              <p className="text-sm font-medium text-white">{item.label}</p>
              <p className="text-xs text-white/40">{item.desc}</p>
            </div>
            <button
              onClick={() => setConfig(c => ({ ...c, [item.key]: !(c as any)[item.key] }))}
              className={clsx(
                'w-11 h-6 rounded-full transition-colors relative flex-shrink-0',
                (config as any)[item.key] ? 'bg-brand' : 'bg-surface-3'
              )}>
              <div className={clsx(
                'absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform',
                (config as any)[item.key] ? 'translate-x-5' : 'translate-x-0.5'
              )} />
            </button>
          </div>
        ))}
      </div>

      {config.dailyReports && (
        <div>
          <label className="form-label">Daily Report Time</label>
          <input type="time" value={config.dailyReportTime}
            onChange={e => setConfig(c => ({ ...c, dailyReportTime: e.target.value }))}
            className="input-base w-auto" />
        </div>
      )}

      <div className="p-4 bg-surface-2 rounded-xl border border-white/5">
        <p className="text-xs text-white/50 mb-2">Setup Instructions</p>
        <ol className="text-xs text-white/40 space-y-1 list-decimal list-inside">
          <li>Create a free account at <span className="text-brand">make.com</span></li>
          <li>Import the SmartPOS scenario template</li>
          <li>Connect your WhatsApp Business account</li>
          <li>Copy the webhook URL to your <code className="text-brand">.env.local</code></li>
        </ol>
      </div>

      <div className="flex gap-3">
        <button onClick={handleTest} disabled={testing} className="btn-secondary flex items-center gap-2">
          <MdWhatsapp size={18} />
          {testing ? 'Sending...' : 'Send Test Message'}
        </button>
        <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2">
          <MdSave size={16} />
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>
    </div>
  );
}
