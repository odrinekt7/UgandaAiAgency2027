// SmartPOS — Shared TypeScript Types

export type UserRole = 'ADMIN' | 'MANAGER' | 'CASHIER';
export type BusinessType = 'RETAIL' | 'PHARMACY' | 'HARDWARE' | 'BOUTIQUE' | 'WHOLESALE' | 'OTHER';
export type PaymentMethod = 'CASH' | 'MTN_MOBILE_MONEY' | 'AIRTEL_MONEY' | 'CARD' | 'BANK_TRANSFER' | 'CREDIT';
export type PurchaseStatus = 'PENDING' | 'ORDERED' | 'RECEIVED' | 'CANCELLED';

// ─── Auth ───────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  businessId: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface LoginPayload {
  email: string;
  password: string;
}

// ─── Products ───────────────────────────────────────────────
export interface Product {
  id: string;
  businessId: string;
  categoryId?: string;
  supplierId?: string;
  name: string;
  localName?: string;
  barcode?: string;
  sku?: string;
  description?: string;
  imageUrl?: string;
  costPrice: number;
  sellingPrice: number;
  taxable: boolean;
  quantity: number;
  minQuantity: number;
  unit: string;
  isActive: boolean;
  category?: { id: string; name: string; color: string };
  supplier?: { id: string; name: string };
  createdAt: string;
  updatedAt: string;
}

export interface CreateProductPayload {
  name: string;
  localName?: string;
  barcode?: string;
  sku?: string;
  categoryId?: string;
  supplierId?: string;
  costPrice: number;
  sellingPrice: number;
  quantity: number;
  minQuantity?: number;
  unit?: string;
  taxable?: boolean;
  description?: string;
}

// ─── Cart & POS ─────────────────────────────────────────────
export interface CartItem {
  product: Product;
  quantity: number;
  discount: number; // percentage
  lineTotal: number;
}

export interface Cart {
  items: CartItem[];
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
}

// ─── Sales ──────────────────────────────────────────────────
export interface Sale {
  id: string;
  businessId: string;
  cashierId: string;
  receiptNumber: string;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  total: number;
  amountPaid: number;
  change: number;
  paymentMethod: PaymentMethod;
  mobileMoneyRef?: string;
  status: 'COMPLETED' | 'REFUNDED' | 'PARTIAL_REFUND';
  synced: boolean;
  createdAt: string;
  cashier: { name: string };
  items: SaleItem[];
}

export interface SaleItem {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  discount: number;
  total: number;
}

export interface CreateSalePayload {
  items: {
    productId: string;
    quantity: number;
    unitPrice: number;
    discount?: number;
  }[];
  paymentMethod: PaymentMethod;
  amountPaid: number;
  discountAmount?: number;
  mobileMoneyRef?: string;
  notes?: string;
}

// ─── Dashboard Analytics ────────────────────────────────────
export interface DashboardStats {
  todaySales: number;
  todayTransactions: number;
  todayProfit: number;
  weekSales: number;
  topProducts: { name: string; quantity: number; revenue: number }[];
  lowStockCount: number;
  salesByDay: { date: string; sales: number; profit: number }[];
  cashierStats: { name: string; sales: number; transactions: number }[];
  paymentBreakdown: { method: string; amount: number; count: number }[];
}

// ─── Inventory ──────────────────────────────────────────────
export interface StockAlert {
  id: string;
  productId: string;
  product: { name: string; quantity: number; unit: string };
  type: 'LOW_STOCK' | 'OUT_OF_STOCK' | 'EXPIRY_SOON';
  message: string;
  isRead: boolean;
  createdAt: string;
}

// ─── Offline Queue ──────────────────────────────────────────
export interface OfflineSale {
  id: string; // local temp id
  payload: CreateSalePayload;
  createdAt: string;
  synced: false;
}

// ─── API Responses ──────────────────────────────────────────
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}
