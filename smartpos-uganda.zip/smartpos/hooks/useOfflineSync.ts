// hooks/useOfflineSync.ts — Syncs offline sales when internet returns

import { useEffect, useState, useCallback } from 'react';
import {
  getPendingOfflineSales,
  removeOfflineSale,
  onOnlineStatusChange,
  getPendingOfflineSalesCount,
} from '@/lib/offline';
import toast from 'react-hot-toast';

export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  // ─── Sync pending offline sales to server ──────────────
  const syncPendingSales = useCallback(async () => {
    const pending = await getPendingOfflineSales();
    if (pending.length === 0) return;

    setIsSyncing(true);
    let synced = 0;
    let failed = 0;

    for (const offlineSale of pending) {
      try {
        const response = await fetch('/api/sales', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...offlineSale.payload,
            offlineId: offlineSale.id,
            createdAt: offlineSale.createdAt, // Preserve original time
          }),
        });

        if (response.ok) {
          await removeOfflineSale(offlineSale.id);
          synced++;
        } else {
          failed++;
        }
      } catch {
        failed++;
      }
    }

    setIsSyncing(false);
    setPendingCount(await getPendingOfflineSalesCount());

    if (synced > 0) {
      toast.success(`✅ Synced ${synced} offline sale${synced > 1 ? 's' : ''}`);
    }
    if (failed > 0) {
      toast.error(`${failed} sale${failed > 1 ? 's' : ''} failed to sync`);
    }
  }, []);

  // ─── Initialize: check status and start listener ───────
  useEffect(() => {
    setIsOnline(navigator.onLine);

    // Load pending count on mount
    getPendingOfflineSalesCount().then(setPendingCount);

    // Listen for online/offline changes
    const cleanup = onOnlineStatusChange(async (online) => {
      setIsOnline(online);
      if (online) {
        toast.success('Back online! Syncing...', { icon: '🌐' });
        await syncPendingSales();
      } else {
        toast('Working offline — sales will sync later', {
          icon: '📴',
          style: { background: '#FF6B35', color: 'white' },
        });
      }
    });

    // Auto-sync if online on mount
    if (navigator.onLine) {
      syncPendingSales();
    }

    return cleanup;
  }, [syncPendingSales]);

  return { isOnline, pendingCount, isSyncing, syncNow: syncPendingSales };
}
