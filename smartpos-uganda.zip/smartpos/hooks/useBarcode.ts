// hooks/useBarcode.ts — USB barcode scanner hook (reads keyboard input bursts)

import { useEffect, useCallback, useRef } from 'react';

interface UseBarcodeOptions {
  onScan: (barcode: string) => void;
  enabled?: boolean;
  minLength?: number;    // Minimum barcode length
  scanDelay?: number;    // Max ms between characters (USB scanners are fast)
}

/**
 * USB barcode scanners act as keyboard input devices.
 * They type characters rapidly and end with an Enter key.
 * This hook detects that pattern and extracts the barcode.
 */
export function useBarcode({
  onScan,
  enabled = true,
  minLength = 3,
  scanDelay = 50, // USB scanners type < 50ms between chars
}: UseBarcodeOptions) {
  const bufferRef = useRef<string>('');
  const lastKeyTimeRef = useRef<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!enabled) return;

      // Ignore if user is typing in an input/textarea (except barcode inputs)
      const target = e.target as HTMLElement;
      const isInputFocused =
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') &&
        !target.getAttribute('data-barcode-input');

      if (isInputFocused) return;

      const now = Date.now();
      const timeSinceLastKey = now - lastKeyTimeRef.current;
      lastKeyTimeRef.current = now;

      // If too much time passed, reset buffer (human typing, not scanner)
      if (timeSinceLastKey > 100 && bufferRef.current.length > 0) {
        bufferRef.current = '';
      }

      if (e.key === 'Enter') {
        // Scanner finished — process barcode
        const barcode = bufferRef.current.trim();
        if (barcode.length >= minLength) {
          onScan(barcode);
        }
        bufferRef.current = '';
      } else if (e.key.length === 1) {
        // Single printable character
        bufferRef.current += e.key;

        // Auto-clear buffer if no Enter within 500ms
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(() => {
          bufferRef.current = '';
        }, 500);
      }
    },
    [enabled, minLength, onScan]
  );

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [handleKeyDown]);
}

// ─── Manual barcode input handler ────────────────────────
export function useBarcodeInput(onScan: (barcode: string) => void) {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const value = (e.target as HTMLInputElement).value.trim();
      if (value) {
        onScan(value);
        (e.target as HTMLInputElement).value = '';
      }
    }
  };

  return { onKeyDown: handleKeyDown };
}
