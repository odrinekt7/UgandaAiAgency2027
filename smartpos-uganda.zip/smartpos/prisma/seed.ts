// prisma/seed.ts — Seed demo data for development and demos

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding SmartPOS demo data...');

  // ─── Create business ─────────────────────────────────
  const business = await prisma.business.upsert({
    where: { id: 'demo-business-001' },
    update: {},
    create: {
      id: 'demo-business-001',
      name: 'Nakato General Store',
      type: 'RETAIL',
      phone: '+256700123456',
      whatsapp: '+256700123456',
      address: 'Kampala Road, Kampala',
      currency: 'UGX',
      taxRate: 0,
      receiptFooter: 'Thank you for shopping at Nakato General Store!',
    },
  });
  console.log(`✅ Business: ${business.name}`);

  // ─── Create users ─────────────────────────────────────
  const adminHash = await bcrypt.hash('demo1234', 12);
  const cashierHash = await bcrypt.hash('cashier123', 12);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@demo.com' },
    update: {},
    create: {
      businessId: business.id,
      name: 'Sarah Nakato',
      email: 'admin@demo.com',
      passwordHash: adminHash,
      role: 'ADMIN',
      phone: '+256700123456',
    },
  });

  const cashier = await prisma.user.upsert({
    where: { email: 'cashier@demo.com' },
    update: {},
    create: {
      businessId: business.id,
      name: 'John Mugisha',
      email: 'cashier@demo.com',
      passwordHash: cashierHash,
      role: 'CASHIER',
    },
  });
  console.log(`✅ Users: ${admin.name} (admin), ${cashier.name} (cashier)`);

  // ─── Create categories ────────────────────────────────
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { id: 'cat-beverages' },
      update: {},
      create: { id: 'cat-beverages', businessId: business.id, name: 'Beverages', color: '#3B82F6' },
    }),
    prisma.category.upsert({
      where: { id: 'cat-grains' },
      update: {},
      create: { id: 'cat-grains', businessId: business.id, name: 'Grains & Flour', color: '#F59E0B' },
    }),
    prisma.category.upsert({
      where: { id: 'cat-household' },
      update: {},
      create: { id: 'cat-household', businessId: business.id, name: 'Household', color: '#8B5CF6' },
    }),
    prisma.category.upsert({
      where: { id: 'cat-personal' },
      update: {},
      create: { id: 'cat-personal', businessId: business.id, name: 'Personal Care', color: '#EC4899' },
    }),
    prisma.category.upsert({
      where: { id: 'cat-snacks' },
      update: {},
      create: { id: 'cat-snacks', businessId: business.id, name: 'Snacks & Confectionery', color: '#EF4444' },
    }),
  ]);
  console.log(`✅ Categories: ${categories.length} created`);

  // ─── Create products ──────────────────────────────────
  const products = [
    // Beverages
    { name: 'Coca Cola 500ml', localName: 'Coke', barcode: '5449000000996', categoryId: 'cat-beverages', costPrice: 2500, sellingPrice: 3000, quantity: 48, unit: 'pcs' },
    { name: 'Riham Water 500ml', localName: 'Maji', barcode: '5010000100932', categoryId: 'cat-beverages', costPrice: 500, sellingPrice: 1000, quantity: 96, unit: 'pcs' },
    { name: 'Novida Pineapple 350ml', barcode: '5449000133328', categoryId: 'cat-beverages', costPrice: 1500, sellingPrice: 2000, quantity: 36, unit: 'pcs' },
    { name: 'Bell Lager 500ml', barcode: '5010000100123', categoryId: 'cat-beverages', costPrice: 3000, sellingPrice: 4000, quantity: 24, unit: 'pcs' },
    // Grains
    { name: 'Maize Flour 2kg', localName: 'Posho', barcode: '6001000123456', categoryId: 'cat-grains', costPrice: 4500, sellingPrice: 5500, quantity: 30, unit: 'bag', minQuantity: 10 },
    { name: 'Sugar 2kg', localName: 'Sukari', barcode: '6001000234567', categoryId: 'cat-grains', costPrice: 6000, sellingPrice: 7000, quantity: 25, unit: 'bag', minQuantity: 8 },
    { name: 'Rice 2kg', localName: 'Mchele', barcode: '6001000345678', categoryId: 'cat-grains', costPrice: 7000, sellingPrice: 8500, quantity: 20, unit: 'bag', minQuantity: 8 },
    { name: 'Cooking Oil 1 Litre', localName: 'Mafuta', barcode: '6001000456789', categoryId: 'cat-grains', costPrice: 7500, sellingPrice: 9000, quantity: 3, unit: 'bottle', minQuantity: 5 }, // Low stock!
    // Household
    { name: 'Omo Washing Powder 500g', localName: 'Sabuni ya nguo', barcode: '8712561234567', categoryId: 'cat-household', costPrice: 4000, sellingPrice: 5000, quantity: 15, unit: 'pcs' },
    { name: 'Airwick Freshener', barcode: '0012345678901', categoryId: 'cat-household', costPrice: 6000, sellingPrice: 8000, quantity: 8, unit: 'pcs' },
    { name: 'Jik Bleach 500ml', barcode: '5010000200345', categoryId: 'cat-household', costPrice: 3500, sellingPrice: 4500, quantity: 0, unit: 'pcs' }, // Out of stock!
    // Personal Care
    { name: 'Colgate Toothpaste 75ml', barcode: '8718951234560', categoryId: 'cat-personal', costPrice: 3000, sellingPrice: 4000, quantity: 20, unit: 'pcs' },
    { name: 'Dettol Soap 120g', localName: 'Sabuni ya dawa', barcode: '6001012345678', categoryId: 'cat-personal', costPrice: 2500, sellingPrice: 3500, quantity: 18, unit: 'pcs' },
    { name: 'Vaseline 250ml', barcode: '8717644012345', categoryId: 'cat-personal', costPrice: 5000, sellingPrice: 7000, quantity: 10, unit: 'pcs' },
    // Snacks
    { name: 'Pringles Original', barcode: '5010000012345', categoryId: 'cat-snacks', costPrice: 8000, sellingPrice: 10000, quantity: 6, unit: 'pcs', minQuantity: 5 },
    { name: 'Oreo Biscuits', barcode: '7622300012345', categoryId: 'cat-snacks', costPrice: 3500, sellingPrice: 4500, quantity: 24, unit: 'pcs' },
    { name: 'Mcvities Digestive', barcode: '5010005012345', categoryId: 'cat-snacks', costPrice: 5000, sellingPrice: 6500, quantity: 12, unit: 'pcs' },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { barcode: p.barcode },
      update: {},
      create: {
        businessId: business.id,
        minQuantity: 5,
        taxable: false,
        ...p,
      },
    });
  }
  console.log(`✅ Products: ${products.length} seeded`);

  console.log('\n🎉 Demo seed complete!\n');
  console.log('─────────────────────────────────────');
  console.log('Admin Login:   admin@demo.com / demo1234');
  console.log('Cashier Login: cashier@demo.com / cashier123');
  console.log('─────────────────────────────────────\n');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
