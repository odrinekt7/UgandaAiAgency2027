'use client';
// components/layout/Sidebar.tsx

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { clsx } from 'clsx';
import toast from 'react-hot-toast';
import {
  MdDashboard, MdPointOfSale, MdInventory2,
  MdBarChart, MdSettings, MdLogout,
  MdWifi, MdWifiOff, MdSync,
} from 'react-icons/md';
import { useOfflineSync } from '@/hooks/useOfflineSync';

interface NavItem {
  href: string;
  label: string;
  icon: React.ReactNode;
  roles?: string[];
}

const navItems: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: <MdDashboard size={20} /> },
  { href: '/pos', label: 'Point of Sale', icon: <MdPointOfSale size={20} /> },
  { href: '/inventory', label: 'Inventory', icon: <MdInventory2 size={20} />, roles: ['ADMIN', 'MANAGER'] },
  { href: '/reports', label: 'Reports', icon: <MdBarChart size={20} />, roles: ['ADMIN', 'MANAGER'] },
  { href: '/settings', label: 'Settings', icon: <MdSettings size={20} />, roles: ['ADMIN'] },
];

interface SidebarProps {
  userRole: string;
  userName: string;
  businessName: string;
}

export function Sidebar({ userRole, userName, businessName }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { isOnline, pendingCount, isSyncing } = useOfflineSync();

  const handleLogout = async () => {
    await fetch('/api/auth/login', { method: 'DELETE' });
    toast.success('Logged out');
    router.push('/');
  };

  const filteredNav = navItems.filter(
    (item) => !item.roles || item.roles.includes(userRole)
  );

  return (
    <aside className="w-60 min-h-screen bg-surface-1 border-r border-white/5 flex flex-col fixed left-0 top-0 z-40">
      {/* Logo */}
      <div className="p-5 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-brand/20 rounded-xl flex items-center justify-center">
            <span className="text-brand text-lg font-bold font-mono">S</span>
          </div>
          <div>
            <p className="text-sm font-bold text-white leading-none">SmartPOS</p>
            <p className="text-xs text-white/40 mt-0.5 truncate max-w-[130px]">{businessName}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1">
        {filteredNav.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={clsx('nav-item', pathname.startsWith(item.href) && 'active')}
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* Offline status */}
      <div className="p-3 border-t border-white/5">
        <div
          className={clsx(
            'flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium',
            isOnline ? 'text-brand/70 bg-brand/5' : 'text-accent-orange/70 bg-accent-orange/5'
          )}
        >
          {isOnline ? <MdWifi size={14} /> : <MdWifiOff size={14} />}
          <span>{isOnline ? 'Online' : 'Offline'}</span>
          {pendingCount > 0 && (
            <span className="ml-auto bg-accent-orange text-white px-1.5 py-0.5 rounded-full text-[10px]">
              {isSyncing ? <MdSync className="animate-spin" /> : `${pendingCount} pending`}
            </span>
          )}
        </div>
      </div>

      {/* User & Logout */}
      <div className="p-3 border-t border-white/5">
        <div className="flex items-center gap-3 px-3 py-2 mb-1">
          <div className="w-8 h-8 rounded-full bg-brand/20 flex items-center justify-center text-brand text-sm font-bold">
            {userName[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{userName}</p>
            <p className="text-xs text-white/40">{userRole}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="nav-item w-full text-red-400/70 hover:text-red-400 hover:bg-red-500/10">
          <MdLogout size={18} />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
