# SmartPOS Uganda 🛒

> **AI-powered Smart Retail POS & Inventory Management SaaS for Uganda Businesses**

Built with Next.js 14, TypeScript, Supabase, Prisma, OpenAI, and Tailwind CSS. Supports offline operation, WhatsApp alerts, barcode scanning, and AI-powered product search.

![Tech Stack](https://img.shields.io/badge/Next.js-14-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3-cyan) ![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green)

---

## ✨ Features

| Feature | Status |
|---|---|
| 🔐 JWT Auth (Admin / Manager / Cashier roles) | ✅ |
| 🛒 Full POS with cart & receipt generation | ✅ |
| 📷 USB Barcode Scanner support | ✅ |
| 🤖 AI Product Search (fuzzy + OpenAI GPT-4o-mini) | ✅ |
| 📦 Inventory management (CRUD, categories, suppliers) | ✅ |
| 📊 Sales dashboard with charts | ✅ |
| 📈 Reports with CSV export | ✅ |
| 📱 WhatsApp alerts via Make.com | ✅ |
| 📴 Offline mode (IndexedDB + auto-sync) | ✅ |
| 📲 PWA installable on mobile/desktop | ✅ |
| 🚀 Vercel deployment ready | ✅ |

---

## 📁 Project Structure

```
smartpos/
├── app/
│   ├── (app)/                    # Protected routes (require auth)
│   │   ├── layout.tsx            # App shell with sidebar
│   │   ├── dashboard/page.tsx    # Sales analytics
│   │   ├── pos/page.tsx          # Point of Sale screen
│   │   ├── inventory/page.tsx    # Inventory management
│   │   ├── reports/page.tsx      # Reports + CSV export
│   │   └── settings/page.tsx     # Business settings
│   ├── api/                      # Backend API routes
│   │   ├── auth/login/route.ts   # Login / Logout
│   │   ├── products/route.ts     # Products CRUD
│   │   ├── products/[id]/route.ts
│   │   ├── sales/route.ts        # Create & list sales
│   │   ├── dashboard/route.ts    # Analytics queries
│   │   ├── ai-search/route.ts    # AI product search
│   │   ├── categories/route.ts
│   │   └── users/route.ts
│   ├── page.tsx                  # Login page
│   ├── layout.tsx                # Root layout (PWA)
│   └── globals.css               # Design system
├── components/
│   └── layout/
│       └── Sidebar.tsx
├── hooks/
│   ├── useBarcode.ts             # USB barcode scanner
│   └── useOfflineSync.ts         # Offline → online sync
├── lib/
│   ├── auth.ts                   # JWT helpers
│   ├── prisma.ts                 # Prisma singleton
│   ├── openai.ts                 # AI search + reports
│   ├── offline.ts                # IndexedDB operations
│   └── whatsapp.ts               # WhatsApp via Make.com
├── store/
│   └── cartStore.ts              # Zustand cart state
├── types/index.ts                # Shared TypeScript types
├── middleware.ts                 # Auth middleware
├── prisma/
│   ├── schema.prisma             # Full database schema
│   └── seed.ts                   # Demo data seeder
├── public/
│   └── manifest.json             # PWA manifest
├── .env.example                  # Environment variables template
├── vercel.json                   # Vercel config
└── next.config.js                # Next.js + PWA config
```

---

## 🚀 Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/yourusername/smartpos-uganda.git
cd smartpos-uganda
```

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment variables
```bash
cp .env.example .env.local
# Edit .env.local with your actual values
```

### 4. Set up Supabase

1. Go to [supabase.com](https://supabase.com) → Create new project
2. Copy your project URL and keys to `.env.local`
3. Go to **Settings → Database** and copy the connection strings

### 5. Set up the database
```bash
# Push schema to Supabase
npm run db:push

# Seed with demo data
npm run db:seed
```

### 6. Run development server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

**Demo logins:**
- Admin: `admin@demo.com` / `demo1234`
- Cashier: `cashier@demo.com` / `cashier123`

---

## 🌍 Deployment to Vercel

### Option A: Vercel Dashboard (Recommended)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) → Import project
3. Connect your GitHub repo
4. Add environment variables in Vercel dashboard
5. Deploy!

### Option B: Vercel CLI
```bash
npm install -g vercel
vercel login
vercel --prod
```

### Required Environment Variables on Vercel

```
DATABASE_URL          → Supabase connection pooling URL
DIRECT_URL            → Supabase direct connection URL
JWT_SECRET            → Random 32+ character string
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
OPENAI_API_KEY
MAKE_WEBHOOK_LOW_STOCK    → (optional)
MAKE_WEBHOOK_DAILY_REPORT → (optional)
```

---

## 📱 WhatsApp Notifications (Make.com)

1. Create free account at [make.com](https://make.com)
2. Create new **Scenario**
3. Add **Webhook** trigger → copy webhook URL
4. Add **WhatsApp Business** module
5. Map the `message` and `to` fields from webhook payload
6. Paste webhook URL in `.env.local`:
   ```
   MAKE_WEBHOOK_LOW_STOCK=https://hook.eu2.make.com/your-id
   MAKE_WEBHOOK_DAILY_REPORT=https://hook.eu2.make.com/your-id
   ```

---

## 🔌 Barcode Scanner Setup

SmartPOS works with **any USB barcode scanner** (no special drivers needed).

1. Plug scanner into USB port
2. Navigate to `/pos` page
3. Scan any product barcode — it auto-searches and adds to cart
4. The scanner must be set to append **Enter** after each scan (default for most scanners)

Tested with: Honeywell 1900, Zebra DS2208, generic USB HID scanners.

---

## 🛡️ Security

- Passwords hashed with **bcrypt** (12 rounds)
- Sessions via **HTTP-only JWT cookies** (8hr expiry)
- All routes protected by **middleware**
- Role-based access: Admin > Manager > Cashier
- Input validation with **Zod** on all API routes
- **Soft deletes** to preserve sales history integrity
- Security headers on all responses

---

## 📈 Scaling to SaaS (Multi-tenant)

The architecture is already multi-tenant ready:
- Every record has a `businessId` foreign key
- Auth middleware validates `businessId` on every request
- To add subscription billing: integrate **Lemon Squeezy** or **Paystack** (Uganda)
- For per-tenant subdomains: add `subdomain` field to `Business` model

---

## 🛠️ Common Commands

```bash
npm run dev          # Start development server
npm run build        # Production build
npm run db:push      # Push schema changes to database
npm run db:studio    # Open Prisma Studio (visual DB browser)
npm run db:seed      # Load demo data
npm run type-check   # TypeScript check without building
```

---

## 🧩 Supported Business Types

| Type | Customizations |
|---|---|
| 🛒 Mini Supermarket | Barcode scanning, bulk pricing |
| 💊 Pharmacy | Drug names, expiry tracking |
| 🔧 Hardware Shop | Unit variants (metres, kg, pcs) |
| 👗 Boutique | Size/colour variants |
| 📦 Wholesale | Bulk pricing, purchase orders |

---

## 📄 License

MIT License — free to use, modify, and sell.

---

Built with ❤️ for Uganda's entrepreneurs.
