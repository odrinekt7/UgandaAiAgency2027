// store/cartStore.ts — Zustand cart state management

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product, CartItem } from '@/types';

interface CartStore {
  items: CartItem[];
  paymentMethod: string;
  amountPaid: number;
  globalDiscount: number; // percentage

  // Actions
  addItem: (product: Product, quantity?: number) => void;
  removeItem: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  updateItemDiscount: (productId: string, discount: number) => void;
  setGlobalDiscount: (discount: number) => void;
  setPaymentMethod: (method: string) => void;
  setAmountPaid: (amount: number) => void;
  clearCart: () => void;

  // Computed
  getSubtotal: () => number;
  getTax: (taxRate: number) => number;
  getTotal: (taxRate: number) => number;
  getChange: (taxRate: number) => number;
  getItemCount: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      paymentMethod: 'CASH',
      amountPaid: 0,
      globalDiscount: 0,

      addItem: (product: Product, quantity = 1) => {
        set((state) => {
          const existing = state.items.find((i) => i.product.id === product.id);

          if (existing) {
            // Increment quantity if already in cart
            return {
              items: state.items.map((i) =>
                i.product.id === product.id
                  ? {
                      ...i,
                      quantity: i.quantity + quantity,
                      lineTotal: (i.quantity + quantity) * i.product.sellingPrice * (1 - i.discount / 100),
                    }
                  : i
              ),
            };
          }

          // Add new item
          const newItem: CartItem = {
            product,
            quantity,
            discount: 0,
            lineTotal: quantity * product.sellingPrice,
          };

          return { items: [...state.items, newItem] };
        });
      },

      removeItem: (productId: string) => {
        set((state) => ({
          items: state.items.filter((i) => i.product.id !== productId),
        }));
      },

      updateQuantity: (productId: string, quantity: number) => {
        if (quantity <= 0) {
          get().removeItem(productId);
          return;
        }
        set((state) => ({
          items: state.items.map((i) =>
            i.product.id === productId
              ? {
                  ...i,
                  quantity,
                  lineTotal: quantity * i.product.sellingPrice * (1 - i.discount / 100),
                }
              : i
          ),
        }));
      },

      updateItemDiscount: (productId: string, discount: number) => {
        set((state) => ({
          items: state.items.map((i) =>
            i.product.id === productId
              ? {
                  ...i,
                  discount,
                  lineTotal: i.quantity * i.product.sellingPrice * (1 - discount / 100),
                }
              : i
          ),
        }));
      },

      setGlobalDiscount: (globalDiscount) => set({ globalDiscount }),
      setPaymentMethod: (paymentMethod) => set({ paymentMethod }),
      setAmountPaid: (amountPaid) => set({ amountPaid }),

      clearCart: () =>
        set({ items: [], amountPaid: 0, globalDiscount: 0, paymentMethod: 'CASH' }),

      getSubtotal: () => {
        const { items, globalDiscount } = get();
        const raw = items.reduce((sum, i) => sum + i.lineTotal, 0);
        return raw * (1 - globalDiscount / 100);
      },

      getTax: (taxRate: number) => {
        const subtotal = get().getSubtotal();
        const taxableItems = get().items.filter((i) => i.product.taxable);
        const taxableAmount = taxableItems.reduce((sum, i) => sum + i.lineTotal, 0);
        return taxableAmount * (taxRate / 100);
      },

      getTotal: (taxRate: number) => {
        return get().getSubtotal() + get().getTax(taxRate);
      },

      getChange: (taxRate: number) => {
        const { amountPaid } = get();
        return Math.max(0, amountPaid - get().getTotal(taxRate));
      },

      getItemCount: () => {
        return get().items.reduce((sum, i) => sum + i.quantity, 0);
      },
    }),
    {
      name: 'smartpos-cart',
      // Only persist the cart items, not payment state
      partialize: (state) => ({ items: state.items }),
    }
  )
);
