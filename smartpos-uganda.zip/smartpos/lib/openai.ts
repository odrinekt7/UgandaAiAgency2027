// lib/openai.ts — AI-powered product search with local Uganda context

import OpenAI from 'openai';
import Fuse from 'fuse.js';
import type { Product } from '@/types';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ─── Fuzzy search (client-side / fast, no API cost) ──────────
export function fuzzySearchProducts(products: Product[], query: string): Product[] {
  if (!query.trim()) return products;

  const fuse = new Fuse(products, {
    keys: [
      { name: 'name', weight: 0.5 },
      { name: 'localName', weight: 0.4 }, // e.g. "Posho", "Sukari", "Dawa"
      { name: 'barcode', weight: 0.1 },
      { name: 'sku', weight: 0.05 },
      { name: 'description', weight: 0.05 },
    ],
    threshold: 0.4, // 0 = exact, 1 = match anything
    includeScore: true,
    minMatchCharLength: 2,
  });

  return fuse.search(query).map((r) => r.item);
}

// ─── AI search with Uganda-specific context ───────────────────
// Use sparingly — costs OpenAI tokens. Call only when fuzzy search returns 0 results.
export async function aiSearchProducts(
  products: Product[],
  query: string
): Promise<{ matches: Product[]; suggestion: string }> {
  // Build a lean product catalog for the prompt (no heavy fields)
  const catalog = products.slice(0, 200).map((p) => ({
    id: p.id,
    name: p.name,
    local: p.localName,
    barcode: p.barcode,
  }));

  const prompt = `You are an AI assistant for a Ugandan retail store POS system.
A cashier searched for: "${query}"

The store's product catalog (id, name, localName, barcode):
${JSON.stringify(catalog, null, 2)}

Tasks:
1. Find the best matching product IDs (consider Uganda local names like "Posho"=maize flour, "Sukari"=sugar, "Mafuta"=cooking oil, "Dawa"=medicine, "Sabuni"=soap, "Ngano"=wheat flour, "Mahindi"=maize, "Simba"=brand names etc.)
2. Correct any typos in the search query
3. Return max 5 product IDs that best match
4. Provide a brief suggestion if nothing matches

Respond in JSON only:
{
  "matchedIds": ["id1", "id2"],
  "correctedQuery": "corrected search term or null",
  "suggestion": "helpful message if no matches, or null"
}`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // Cheapest model — sufficient for search
      messages: [{ role: 'user', content: prompt }],
      response_format: { type: 'json_object' },
      max_tokens: 300,
      temperature: 0.1,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    const matchedIds: string[] = result.matchedIds || [];

    const matches = products.filter((p) => matchedIds.includes(p.id));

    return {
      matches,
      suggestion: result.suggestion || result.correctedQuery || '',
    };
  } catch (error) {
    console.error('OpenAI search error:', error);
    return { matches: [], suggestion: 'Search temporarily unavailable.' };
  }
}

// ─── Generate daily report summary ───────────────────────────
export async function generateDailyReportSummary(stats: {
  totalSales: number;
  transactions: number;
  topProducts: { name: string; quantity: number }[];
  profit: number;
  lowStockItems: string[];
}): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'user',
          content: `Generate a brief, friendly WhatsApp business report summary for a Ugandan shop owner.
Data: ${JSON.stringify(stats)}
Currency: UGX. Keep it under 200 words. Use simple English. Include emojis. Be encouraging.`,
        },
      ],
      max_tokens: 250,
      temperature: 0.7,
    });

    return response.choices[0].message.content || 'Report generated.';
  } catch {
    return `📊 Daily Report\nSales: UGX ${stats.totalSales.toLocaleString()}\nTransactions: ${stats.transactions}\nProfit: UGX ${stats.profit.toLocaleString()}`;
  }
}
