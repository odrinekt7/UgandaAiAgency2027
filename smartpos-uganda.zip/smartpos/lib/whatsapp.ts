// lib/whatsapp.ts — WhatsApp notifications via Make.com webhooks

interface LowStockAlertPayload {
  businessName: string;
  whatsappNumber: string;
  products: {
    name: string;
    quantity: number;
    unit: string;
    minQuantity: number;
  }[];
}

interface DailyReportPayload {
  businessName: string;
  whatsappNumber: string;
  date: string;
  totalSales: number;
  transactions: number;
  profit: number;
  topProduct: string;
  currency: string;
  aiSummary?: string;
}

// ─── Send Low Stock Alert via Make.com ────────────────────
export async function sendLowStockAlert(payload: LowStockAlertPayload): Promise<boolean> {
  const webhookUrl = process.env.MAKE_WEBHOOK_LOW_STOCK;
  if (!webhookUrl) {
    console.warn('MAKE_WEBHOOK_LOW_STOCK not configured');
    return false;
  }

  try {
    const message = formatLowStockMessage(payload);

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: payload.whatsappNumber,
        message,
        businessName: payload.businessName,
        type: 'LOW_STOCK_ALERT',
        products: payload.products,
        timestamp: new Date().toISOString(),
      }),
    });

    return response.ok;
  } catch (error) {
    console.error('Failed to send low stock alert:', error);
    return false;
  }
}

// ─── Send Daily Report via Make.com ───────────────────────
export async function sendDailyReport(payload: DailyReportPayload): Promise<boolean> {
  const webhookUrl = process.env.MAKE_WEBHOOK_DAILY_REPORT;
  if (!webhookUrl) {
    console.warn('MAKE_WEBHOOK_DAILY_REPORT not configured');
    return false;
  }

  try {
    const message = payload.aiSummary || formatDailyReportMessage(payload);

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: payload.whatsappNumber,
        message,
        businessName: payload.businessName,
        type: 'DAILY_REPORT',
        data: payload,
        timestamp: new Date().toISOString(),
      }),
    });

    return response.ok;
  } catch (error) {
    console.error('Failed to send daily report:', error);
    return false;
  }
}

// ─── Message Formatters ───────────────────────────────────
function formatLowStockMessage(payload: LowStockAlertPayload): string {
  const items = payload.products
    .map((p) => `• ${p.name}: ${p.quantity} ${p.unit} remaining (min: ${p.minQuantity})`)
    .join('\n');

  return `⚠️ *Low Stock Alert — ${payload.businessName}*

The following items need restocking:

${items}

Please reorder soon to avoid running out.
_SmartPOS Uganda_`;
}

function formatDailyReportMessage(payload: DailyReportPayload): string {
  return `📊 *Daily Sales Report — ${payload.businessName}*
📅 ${payload.date}

💰 Total Sales: ${payload.currency} ${payload.totalSales.toLocaleString()}
🧾 Transactions: ${payload.transactions}
📈 Est. Profit: ${payload.currency} ${payload.profit.toLocaleString()}
🏆 Top Product: ${payload.topProduct}

Keep up the great work! 💪
_SmartPOS Uganda_`;
}
