// lib/offline.ts — IndexedDB offline storage for sales and products

import { openDB, DBSchema, IDBPDatabase } from 'idb';
import type { Product, OfflineSale, CreateSalePayload } from '@/types';

// ─── Database Schema ──────────────────────────────────────
interface SmartPOSDB extends DBSchema {
  products: {
    key: string;
    value: Product;
    indexes: {
      'by-barcode': string;
      'by-name': string;
    };
  };
  offlineSales: {
    key: string;
    value: OfflineSale;
  };
  settings: {
    key: string;
    value: { key: string; value: unknown };
  };
}

let db: IDBPDatabase<SmartPOSDB> | null = null;

// ─── Initialize DB ────────────────────────────────────────
export async function initDB(): Promise<IDBPDatabase<SmartPOSDB>> {
  if (db) return db;

  db = await openDB<SmartPOSDB>('smartpos-offline', 1, {
    upgrade(database) {
      // Products store
      const productStore = database.createObjectStore('products', { keyPath: 'id' });
      productStore.createIndex('by-barcode', 'barcode', { unique: true });
      productStore.createIndex('by-name', 'name');

      // Offline sales queue
      database.createObjectStore('offlineSales', { keyPath: 'id' });

      // App settings cache
      database.createObjectStore('settings', { keyPath: 'key' });
    },
  });

  return db;
}

// ─── Products ─────────────────────────────────────────────
export async function cacheProducts(products: Product[]): Promise<void> {
  const database = await initDB();
  const tx = database.transaction('products', 'readwrite');
  await Promise.all([
    ...products.map((p) => tx.store.put(p)),
    tx.done,
  ]);
}

export async function getProductByBarcode(barcode: string): Promise<Product | undefined> {
  const database = await initDB();
  return database.getFromIndex('products', 'by-barcode', barcode);
}

export async function getAllCachedProducts(): Promise<Product[]> {
  const database = await initDB();
  return database.getAll('products');
}

export async function searchCachedProducts(query: string): Promise<Product[]> {
  const products = await getAllCachedProducts();
  const q = query.toLowerCase();
  return products.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.localName?.toLowerCase().includes(q) ||
      p.barcode?.includes(q) ||
      p.sku?.toLowerCase().includes(q)
  );
}

// ─── Offline Sales Queue ──────────────────────────────────
export async function queueOfflineSale(payload: CreateSalePayload): Promise<string> {
  const database = await initDB();
  const id = `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const offlineSale: OfflineSale = {
    id,
    payload,
    createdAt: new Date().toISOString(),
    synced: false,
  };

  await database.put('offlineSales', offlineSale);
  return id;
}

export async function getPendingOfflineSales(): Promise<OfflineSale[]> {
  const database = await initDB();
  return database.getAll('offlineSales');
}

export async function removeOfflineSale(id: string): Promise<void> {
  const database = await initDB();
  await database.delete('offlineSales', id);
}

export async function getPendingOfflineSalesCount(): Promise<number> {
  const database = await initDB();
  return database.count('offlineSales');
}

// ─── Check online status ──────────────────────────────────
export function isOnline(): boolean {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}

export function onOnlineStatusChange(callback: (online: boolean) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handleOnline = () => callback(true);
  const handleOffline = () => callback(false);

  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);

  return () => {
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
  };
}
