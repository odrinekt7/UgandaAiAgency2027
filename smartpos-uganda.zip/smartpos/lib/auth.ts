// lib/auth.ts — JWT-based authentication helpers

import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { NextRequest } from 'next/server';
import type { AuthUser } from '@/types';

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'fallback-dev-secret-change-in-production'
);

const COOKIE_NAME = 'smartpos_session';
const TOKEN_EXPIRY = '8h'; // Cashier sessions expire after 8 hours

// ─── Create JWT token ─────────────────────────────────────
export async function createToken(user: AuthUser): Promise<string> {
  return new SignJWT({
    id: user.id,
    businessId: user.businessId,
    name: user.name,
    email: user.email,
    role: user.role,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(TOKEN_EXPIRY)
    .sign(SECRET);
}

// ─── Verify JWT token ─────────────────────────────────────
export async function verifyToken(token: string): Promise<AuthUser | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as unknown as AuthUser;
  } catch {
    return null;
  }
}

// ─── Get current user from request cookies ────────────────
export async function getCurrentUser(req?: NextRequest): Promise<AuthUser | null> {
  let token: string | undefined;

  if (req) {
    // From API route request
    token = req.cookies.get(COOKIE_NAME)?.value;
  } else {
    // From Server Component
    const cookieStore = cookies();
    token = cookieStore.get(COOKIE_NAME)?.value;
  }

  if (!token) return null;
  return verifyToken(token);
}

// ─── Cookie options ───────────────────────────────────────
export const cookieOptions = {
  name: COOKIE_NAME,
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: 60 * 60 * 8, // 8 hours in seconds
};

// ─── Role permission checks ───────────────────────────────
export function canManageInventory(role: string): boolean {
  return role === 'ADMIN' || role === 'MANAGER';
}

export function canViewReports(role: string): boolean {
  return role === 'ADMIN' || role === 'MANAGER';
}

export function canManageSettings(role: string): boolean {
  return role === 'ADMIN';
}

export function canProcessSales(role: string): boolean {
  return true; // All roles can process sales
}
