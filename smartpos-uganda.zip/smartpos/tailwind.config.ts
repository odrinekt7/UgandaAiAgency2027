import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-outfit)', 'sans-serif'],
        mono: ['var(--font-ibm-plex-mono)', 'monospace'],
        body: ['var(--font-outfit)', 'sans-serif'],
      },
      colors: {
        // SmartPOS Design System
        surface: {
          DEFAULT: '#0D1117',
          1: '#161B22',
          2: '#1C2230',
          3: '#21283A',
          4: '#2A3347',
        },
        brand: {
          DEFAULT: '#00D4AA',
          50: '#E6FAF6',
          100: '#B3F0E6',
          500: '#00D4AA',
          600: '#00B890',
          700: '#009B79',
        },
        accent: {
          orange: '#FF6B35',
          yellow: '#FFB800',
          blue: '#3B82F6',
          red: '#EF4444',
          green: '#22C55E',
        },
        border: {
          DEFAULT: 'rgba(255,255,255,0.07)',
          active: 'rgba(0,212,170,0.4)',
        },
      },
      backgroundImage: {
        'grid-pattern':
          'linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)',
        'glow-brand':
          'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(0,212,170,0.12) 0%, transparent 70%)',
      },
      backgroundSize: {
        grid: '40px 40px',
      },
      animation: {
        'slide-in': 'slideIn 0.2s ease-out',
        'fade-up': 'fadeUp 0.3s ease-out',
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'scan-line': 'scanLine 1.5s ease-in-out infinite',
      },
      keyframes: {
        slideIn: {
          from: { transform: 'translateX(-10px)', opacity: '0' },
          to: { transform: 'translateX(0)', opacity: '1' },
        },
        fadeUp: {
          from: { transform: 'translateY(8px)', opacity: '0' },
          to: { transform: 'translateY(0)', opacity: '1' },
        },
        scanLine: {
          '0%, 100%': { top: '0%', opacity: '1' },
          '50%': { top: '100%', opacity: '0.5' },
        },
      },
      boxShadow: {
        brand: '0 0 20px rgba(0,212,170,0.2)',
        'inner-brand': 'inset 0 1px 0 rgba(0,212,170,0.1)',
        card: '0 4px 24px rgba(0,0,0,0.4)',
      },
    },
  },
  plugins: [],
};

export default config;
